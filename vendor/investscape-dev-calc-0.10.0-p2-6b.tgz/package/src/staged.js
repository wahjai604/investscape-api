'use strict';
/**
 * Staged (multi-phase) roll-up and XIRR, P2-2D.
 *
 * Mechanically relocated from investscape-v2-remastered.html (reference SHA-256 84cf6e13...c193c83): smoothstep(),
 * smoothstepAverageDrawFactor(), calculateXIRR() and computeStagedRollup(). The text is byte-identical to the page except for
 * the documented boundary edits to computeStagedRollup:
 *   1. the signature gains an explicit fifth argument  deps  (carrying the injected calc engine, deps.CALC);
 *   2. its single call  devstudioCompute(merged)  becomes  devstudioCompute(merged, deps)  and uses the extracted Full calculation.
 *
 * Dependencies traced from the page text: devstudioCompute (Full), smoothstepAverageDrawFactor (-> smoothstep) and
 * calculateXIRR. There is NO state, DOM, translation, formatting, storage or clock access in this code (the schedule is in
 * whole months from t=0; no calendar dates are used). Persistence of stages, UI and project creation are not part of this module.
 *
 * RAW LEGACY BEHAVIOUR preserved on purpose: stage merge rule {...baseInputs, ...stage}; per-stage RLV is the financing-EXCLUDED
 * linear value netRevenue/(1+m) - K (NOT the single-phase financing-inclusive solver); the two recycling policies
 * ("maximal", "distribute-interim"; any other string behaves as "maximal"); the shared-financing allocation; the XIRR algorithm
 * (Newton from 0.15, then bisection on [-0.9, 10]); errors inside the per-stage devstudioCompute call are swallowed (that stage
 * contributes zero), exactly as on the page. No validation, clamping or status.
 */
const { devstudioCompute } = require('./full');

function smoothstep(x){ return x<=0?0 : x>=1?1 : 3*x*x - 2*x*x*x; }
// Discrete average of the curve's cumulative-drawn fraction across whole
// construction months (matches the chart's own per-month discretization,
// not the continuous integral) — for any reasonably long construction
// period this converges to the continuous integral's exact 0.5 (smoothstep
// is point-symmetric about (0.5, 0.5)), but computing it this way keeps the
// UI's numbers internally consistent with the chart's own month buckets
// rather than silently switching to a different, slightly-off convention.
function smoothstepAverageDrawFactor(months){
  const m = Math.max(1, Math.round(months));
  let sum = 0;
  for(let month=1; month<=m; month++){ sum += smoothstep(month/m); }
  return sum/m;
}
// Layer 2B (2026-08-29 continued) — XIRR solver for irregularly-timed cash
// flows. Needed because a staged project's equity goes out and comes back
// at DIFFERENT times per stage (stage 1 might run 18 months, stage 2 might
// start overlapping or sequentially at a different month) — the existing
// CALC.calculateIRR()/buildInvestmentCashFlowSeries() pair (used by
// residential deals, line ~6724) assumes one cash flow per whole year,
// which doesn't fit a multi-stage timeline with arbitrary month offsets.
// XIRR (cash flows at arbitrary points in time, in years) is the correct
// and standard tool for this — not a workaround, the industry-standard
// approach real underwriters use for exactly this shape of problem.
// Newton's method with a bisection fallback (Newton alone can diverge on
// cash-flow series with unusual sign patterns).
function calculateXIRR(cashFlows){
  // cashFlows: [{ years: number, amount: number }, ...] — years is time
  // from t=0 in fractional years, amount negative for outflows.
  if(!cashFlows || cashFlows.length < 2) return null;
  const hasPositive = cashFlows.some(cf=>cf.amount>0);
  const hasNegative = cashFlows.some(cf=>cf.amount<0);
  if(!hasPositive || !hasNegative) return null; // no sign change — no real solution
  const npv = (rate) => cashFlows.reduce((s,cf)=>s + cf.amount/Math.pow(1+rate, cf.years), 0);
  const dNpv = (rate) => cashFlows.reduce((s,cf)=>s - cf.years*cf.amount/Math.pow(1+rate, cf.years+1), 0);
  let rate = 0.15; // reasonable starting guess for a development-scale IRR
  let converged = false;
  for(let iter=0; iter<50; iter++){
    const f = npv(rate);
    const fPrime = dNpv(rate);
    if(Math.abs(f) < 1e-6){ converged = true; break; }
    if(Math.abs(fPrime) < 1e-12) break; // avoid divide-by-near-zero
    const next = rate - f/fPrime;
    if(next <= -0.999) { rate = -0.5; continue; } // keep discount rate above -100%
    rate = next;
  }
  if(converged) return rate;
  // Bisection fallback over a wide, sane range if Newton didn't converge.
  let lo = -0.9, hi = 10;
  let fLo = npv(lo), fHi = npv(hi);
  if(fLo*fHi > 0) return null; // no sign change in range — genuinely unsolvable, not fabricated
  for(let iter=0; iter<200; iter++){
    const mid = (lo+hi)/2;
    const fMid = npv(mid);
    if(Math.abs(fMid) < 1e-6) return mid;
    if(fLo*fMid < 0){ hi = mid; fHi = fMid; } else { lo = mid; fLo = fMid; }
  }
  return (lo+hi)/2;
}
// Layer 2B (2026-08-29) — Multi-phase development staging.
//
// A "stage" is a PARTIAL override object (name + whichever of landCost/
// buildableSf/unitsTotal/avgUnitPrice/hardCostPsf/softCostPct/contingencyPct/
// constructionMonths/requiredProfitMarginPct differ from the project's own
// `inputs`). Each stage is run through the EXACT SAME devstudioCompute()
// the single-phase project already uses (it already accepts overrideInputs
// — this reuses that, doesn't fork it), so a stage's TDC/profit/margin are
// computed with zero duplicated math and stay correct if devstudioCompute
// itself changes later.
//
// RLV per stage reuses the identical linear formula already shipped for the
// single-phase project (Land & Site tab, Item 1): K = hard+soft+contingency,
// m = requiredProfitMarginPct/100, RLV = netRevenue/(1+m) - K. Finance costs
// are excluded from the solve for the same disclosed reason as the
// single-phase version — a real circularity (loan size depends on land
// cost) this simplified formula doesn't resolve.
//
// Timeline is SEQUENTIAL only (stage 2 starts the month stage 1's
// construction ends) — deliberately not modeling overlapping/staggered
// phases yet. That's a real simplification for schemes that actually
// overlap phases to compress the timeline, disclosed in the UI footnote,
// not silently assumed away.
// Project-level IRR model (2026-08-29, extended same day per Eric's request
// to close both gaps flagged when this first shipped: interim financing
// cost, and equity recycling between stages).
//
// FINANCING COST: each stage's `out.facilities` (from the SAME
// devstudioCompute() call, not a separate calculation) already contains a
// real, already-computed `interestReserveAmount` per facility — the exact
// construction-loan interest-reserve figure the single-phase project's own
// Overview/Sources≡Uses tabs already use (see buildFinancingFacilities()).
// Summing it across a stage's facilities and deducting it from that stage's
// exit cash flow is not new math — it's finally USING a number the engine
// was already computing but this rollup wasn't reading yet.
//
// EQUITY RECYCLING: real multi-phase developers don't raise 100% fresh
// equity for every phase — proceeds from an earlier phase's exit fund a
// later phase's equity requirement before any new capital is called. This
// function tracks a running `equityPool`: at each stage's start, its equity
// need is drawn from the pool first (free, no external cash flow), and only
// the shortfall becomes an actual investor cash call. At each stage's exit,
// its net proceeds refill the pool. The policy modeled is MAXIMAL
// recycling — reinvest everything possible, distribute to investors only
// once there's no further stage left to absorb it (i.e. the true leftover
// at the end). That's a stated policy choice, not the only one a real
// sponsor might pick (some distribute interim profits instead) — disclosed
// in the UI footnote, not presented as the only correct answer.
//
// Net-of-financing identity: equityReturnNet = profit + equity -
// financingCost. (profit + equity = netRevenue - totalDebtFacilities, i.e.
// what's left for equity before financing cost; financingCost is then
// deducted because it's a real cash cost devstudioCompute's own `profit`
// figure does NOT yet subtract — profit = netRevenue - tdc, and tdc has
// never included interest. This rollup is the first place in the app that
// actually nets it out.)
// STAGE-MILESTONE DEPENDENCIES (2026-08-29, follow-on closed same session as
// the percentage-rent fix below): previously a stage's start was purely
// elapsed-time (stage N starts the instant stage N-1's construction ends).
// This was flagged in the Layer 3 Known Limitations doc as a real gap —
// real multi-phase schemes often gate a later phase's start on a genuine
// milestone (e.g. "Stage 2 can't start until 80% of Stage 1 is presold"),
// not just the calendar.
//
// Per-stage opt-in fields (undefined/false on any existing stage = zero
// behavior change, byte-identical to the pure elapsed-time model):
//   requiresPresaleGate: boolean — opts this stage into a gate at all
//   presaleGateThresholdPercent: the required presale % (mirrors the
//     single-phase project's own presaleGateThresholdPercent convention)
//   currentPresoldPercent: SELF-REPORTED current presale % for the PRIOR
//     stage (this is the "how do you know" input — there's no live sales
//     feed, same honesty convention as the single-phase presale gate's own
//     self-reported pace inputs)
//   estimatedMonthsToGate: SELF-REPORTED estimate of how many additional
//     months are needed to hit the gate if it isn't met yet (0 if
//     currentPresoldPercent already clears the threshold)
// The gate can only ever ADD delay on top of the elapsed-time cursor, never
// pull a stage's start earlier — a milestone gate is a floor, not a
// schedule optimizer.
// Revised 2026-08-29 (closing 3 more items off the Layer 3 Known
// Limitations doc, each backward compatible via a sensible default):
// - STAGE OVERLAP: a stage after the first can now set `overlapMonths` to
//   start earlier than pure elapsed time would allow (compressing the
//   timeline, the way real multi-phase schemes often do) — capped so it
//   can never start before the PRIOR stage's own start (can't fully swallow
//   it) and never before month 0. Default 0 = pure sequential, unchanged.
// - EQUITY RECYCLING POLICY: `recyclingPolicy` param, default 'maximal'
//   (unchanged prior behavior — recycle everything possible, distribute
//   only the final leftover). New option 'distribute-interim': every
//   stage's net return is distributed to investors immediately at ITS OWN
//   completion instead of being recycled into the next stage, and every
//   stage calls 100% fresh equity — the literal alternative policy this
//   doc always said wasn't modeled.
// - IRR TIMING: fresh equity calls are now placed at each stage's
//   S-CURVE-WEIGHTED AVERAGE DRAW MONTH (via smoothstepAverageDrawFactor,
//   the SAME curve already used for interest-reserve calculations — not
//   new math) instead of a lump at the stage's exact start month. Equity is
//   drawn progressively through construction just like debt is; the exit
//   proceeds timing (stage end) is unchanged. Still a two-point-per-stage
//   model, not a monthly curve — just a more accurately TIMED two points.
// SHARED/BLENDED CROSS-STAGE FINANCING (2026-08-29, closes the last
// remaining Dev Studio Known Limitations item). Previously each stage's
// financing cost came from its OWN independent construction loan, sized and
// timed as if that stage's debt was fully repaid the instant that stage
// completed. A real shared facility financing multiple phases doesn't
// necessarily work that way — stage 1's draw can still be outstanding when
// stage 2 begins drawing, so interest keeps accruing on the combined
// balance across the WHOLE multi-stage timeline, not just each stage's own
// window.
//
// Two-pass structure: PASS 1 computes every stage's own tdc/loanAmount/
// timeline exactly as before (needed to know the combined timeline and
// total loan amount before shared financing can be computed at all). PASS 2
// runs the identical equity-pool/cash-flow logic as the single-pass version
// used to, just swapping in a SHARED financing cost (when opted into)
// allocated back to each stage proportional to its own loan amount — a
// disclosed allocation convention, not a claim that costs are literally
// billed that way.
//
// sharedFinancingCost = totalLoanAmount × interestReservePercent% ×
// (totalTimelineMonths/12) × blendedFinancingRate% × withdrawalFactor — the
// SAME formula each stage's own independent interest reserve already uses
// (buildFinancingFacilities' seniorInterestReserve), just applied to the
// COMBINED loan amount over the COMBINED timeline instead of per-stage.
// This is mathematically LARGER than the sum of independent per-stage
// costs (cross-terms: stage 1's balance now also accrues interest during
// stage 2+'s window) — that's the real, intended difference a shared
// facility implies, not a bug. Disclosed as a real simplification: a truly
// modeled shared facility would need an actual combined draw/paydown
// schedule, not a single blended-rate-over-combined-timeline formula.
function computeStagedRollup(baseInputs, stages, recyclingPolicy, useSharedFinancing, deps){
  const list = stages || [];
  if(!list.length) return null; // no stages defined — caller falls back to single-phase display
  const policy = recyclingPolicy === 'distribute-interim' ? 'distribute-interim' : 'maximal';

  // PASS 1 — timeline, TDC, loan sizing per stage. No financing-cost
  // decision yet; shared financing needs the FULL timeline/loan totals
  // first, which don't exist until every stage has been walked once.
  let cursorMonth = 0, previousStageStartMonth = 0;
  const prelim = list.map((stage, idx) => {
    const merged = { ...baseInputs, ...stage };
    let out;
    try { out = devstudioCompute(merged, deps); }
    catch(e) { out = null; }
    const K = out ? (out.hardCost + out.softCost + out.contingency) : 0;
    const m = (merged.requiredProfitMarginPct||0)/100;
    const rlv = out ? (out.netRevenue/(1+m)) - K : 0;
    // Overlap can only pull a stage earlier, never past its own predecessor's
    // start (idx===0 has no predecessor to overlap with, floor stays 0).
    const overlapMonths = idx > 0 ? Math.max(0, Math.round(stage.overlapMonths||0)) : 0;
    const overlappedEarliestStart = Math.max(previousStageStartMonth, cursorMonth - overlapMonths);
    const earliestStartMonth = overlappedEarliestStart;
    const gateApplies = idx > 0 && !!stage.requiresPresaleGate; // stage 0 has no prior stage to gate on
    const gateThreshold = stage.presaleGateThresholdPercent ?? 80;
    const gateCurrentPercent = stage.currentPresoldPercent ?? 0;
    const gateMet = !gateApplies || gateCurrentPercent >= gateThreshold;
    const gateDelayMonths = gateApplies && !gateMet ? Math.max(0, Math.round(stage.estimatedMonthsToGate||0)) : 0;
    const startMonth = earliestStartMonth + gateDelayMonths;
    const durationMonths = Math.max(1, Math.round(merged.constructionMonths||0));
    const endMonth = startMonth + durationMonths;
    cursorMonth = endMonth;
    previousStageStartMonth = startMonth;
    const independentFinancingCost = out ? (out.facilities||[]).reduce((s,f)=>s+(f.interestReserveAmount||0), 0) : 0;
    const loanAmount = out ? (out.loanAmount||0) : 0;
    return { idx, merged, out, K, rlv, overlapMonths, earliestStartMonth, startMonth, endMonth, durationMonths, gateApplies, gateMet, gateDelayMonths, gateThreshold, gateCurrentPercent, independentFinancingCost, loanAmount };
  });
  const totalTimelineMonths = cursorMonth;
  const totalLoanAmount = prelim.reduce((s,p)=>s+p.loanAmount, 0);
  let sharedFinancingCost = null;
  if(useSharedFinancing && totalLoanAmount > 0){
    const blendedFinancingRate = prelim.reduce((s,p)=>s+(p.merged.financingRate||0)*p.loanAmount, 0) / totalLoanAmount;
    const interestReservePercent = baseInputs.interestReservePercent||0;
    const withdrawalFactor = baseInputs.withdrawalFactor||0;
    sharedFinancingCost = totalLoanAmount * (interestReservePercent/100) * (totalTimelineMonths/12) * (blendedFinancingRate/100) * withdrawalFactor;
  }

  // PASS 2 — identical equity-pool/cash-flow logic as the original
  // single-pass version, just reading `financingCost` from either the
  // independent per-stage figure or this stage's proportional share of the
  // shared facility, decided once above.
  let totalLandCost=0, totalTdc=0, totalNetRevenue=0, totalProfit=0, totalRlv=0;
  let totalFreshEquity=0, totalFinancingCost=0, totalDistributions=0;
  let equityPool = 0;
  const cashFlows = [];
  const perStage = prelim.map((p, idx) => {
    const { merged, out, K, rlv, overlapMonths, earliestStartMonth, startMonth, endMonth, durationMonths, gateApplies, gateMet, gateDelayMonths, gateThreshold, gateCurrentPercent, loanAmount } = p;
    const isLastStage = idx === prelim.length - 1;
    const financingCost = useSharedFinancing && sharedFinancingCost != null
      ? sharedFinancingCost * (totalLoanAmount > 0 ? loanAmount / totalLoanAmount : 0)
      : p.independentFinancingCost;

    const equityNeeded = out ? out.equity : 0;
    const drawnFromPool = policy==='maximal' ? Math.min(equityPool, equityNeeded) : 0;
    const freshEquityCall = equityNeeded - drawnFromPool;
    equityPool -= drawnFromPool;
    // Equity is drawn progressively through construction, same S-curve
    // convention as the interest-reserve calc — not a day-1 lump.
    const drawWeightedMonth = startMonth + durationMonths * smoothstepAverageDrawFactor(durationMonths);
    if(freshEquityCall > 1e-6){
      cashFlows.push({ years: drawWeightedMonth/12, amount: -freshEquityCall });
      totalFreshEquity += freshEquityCall;
    }
    const equityReturnNet = out ? (out.profit + out.equity - financingCost) : 0;
    equityPool += equityReturnNet;
    // MAXIMAL policy: only the FINAL leftover pool is ever distributed —
    // every intermediate stage's proceeds are assumed recycled into
    // whatever the next stage needs. DISTRIBUTE-INTERIM policy: every
    // stage's own net return is distributed right away, nothing recycled.
    const shouldDistributeNow = policy==='distribute-interim' || isLastStage;
    if(shouldDistributeNow && Math.abs(equityPool) > 1e-6){
      cashFlows.push({ years: endMonth/12, amount: equityPool });
      totalDistributions += equityPool;
      equityPool = 0;
    }
    if(out){
      totalLandCost += merged.landCost||0;
      totalTdc += out.tdc;
      totalNetRevenue += out.netRevenue;
      totalProfit += out.profit;
      totalRlv += rlv;
      totalFinancingCost += financingCost;
    }
    return {
      name: merged.name || `Stage ${idx+1}`,
      landCost: merged.landCost||0, requiredProfitMarginPct: merged.requiredProfitMarginPct,
      overlapMonths, earliestStartMonth, startMonth, endMonth, durationMonths,
      gateApplies, gateMet, gateDelayMonths, gateThreshold, gateCurrentPercent,
      tdc: out?out.tdc:0, netRevenue: out?out.netRevenue:0, profit: out?out.profit:0,
      marginOnCost: out?out.marginOnCost:0, rlv, loanAmount,
      equityNeeded, drawnFromPool, freshEquityCall, financingCost, equityReturnNet
    };
  });
  const irr = calculateXIRR(cashFlows);
  return {
    stages: perStage, recyclingPolicy: policy,
    useSharedFinancing: !!useSharedFinancing, sharedFinancingCost, totalLoanAmount,
    totalLandCost, totalTdc, totalNetRevenue, totalProfit, totalRlv,
    totalFreshEquity, totalFinancingCost, totalDistributions,
    equityMultiple: totalFreshEquity>0 ? totalDistributions/totalFreshEquity : null,
    irr,
    blendedMarginOnCost: totalTdc>0 ? totalProfit/totalTdc : 0,
    totalTimelineMonths: cursorMonth
  };
}

module.exports = { smoothstep, smoothstepAverageDrawFactor, calculateXIRR, computeStagedRollup };
