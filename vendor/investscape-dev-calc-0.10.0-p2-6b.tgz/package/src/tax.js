'use strict';
/**
 * Development Studio tax applicability, P2-2E.
 *
 * Mechanically relocated from investscape-v2-remastered.html (reference SHA-256 84cf6e13...c193c83): the constant
 * DEV_TAX_JURISDICTIONS and devstudioTaxApplicability(). The function text is byte-identical to the page except for the
 * documented boundary edits:
 *   1. the signature gains an explicit third argument  deps  (carrying the injected tax engine, deps.TAX);
 *   2. the page-global TAX reference becomes  const TAX = deps.TAX;
 *   3. DEV_TAX_JURISDICTIONS is frozen (the page leaves it mutable; nothing on the page writes to it).
 * The page's explanatory comment block above the constant is not copied; the same facts are recorded in the package README.
 *
 * Dependencies traced from the page text: TAX.developerProfit (E51) and TAX.gstHstDevCharges (E52), called with the argument
 * objects shown below, and the constant. No state, DOM, translation, formatting, storage or clock is read here. (The embedded
 * engine stamps its own return values with the current time; this function never reads those fields, so its result has no
 * time dependence.) devstudioTaxCardHtml, its formatting and translation stay outside this module: the unresolved-disclosure
 * entries keep their raw {key, fb, vars}.
 *
 * RAW LEGACY BEHAVIOUR preserved on purpose, including: E51 arithmetic is gross sales - hard - soft only (not Project Profit, not
 * taxable income); no after-tax figure for any jurisdiction (the rate is never passed); E52 assumes a registered developer and
 * residential units and is Canada-only; "unavailable" is never exempt or zero; a non-BC/ON/US value is unsupported and is never
 * substituted. No tax rate is supplied here and no jurisdiction is added.
 */
const DEV_TAX_JURISDICTIONS = Object.freeze({ BC:'CA', ON:'CA', US:'US' });
function devstudioTaxApplicability(i, out, deps){
  const TAX = deps.TAX;
  const has = (o,k) => Object.prototype.hasOwnProperty.call(o,k);
  const ps = i.provinceState;
  const region = has(DEV_TAX_JURISDICTIONS, ps) ? DEV_TAX_JURISDICTIONS[ps] : null;
  const res = { provinceState:ps, region, supported:region!==null, e51:{status:'unsupported'}, e52:{status:'unsupported'}, e82:{status:ps==='BC'?'supported':'unsupported'}, unresolved:[] };
  const note = (key, fb, vars) => res.unresolved.push({ key, fb, vars });
  if(region===null){
    note('tax.unsupportedJurisdiction','Tax not calculated: "{ps}" is not a jurisdiction the Development Studio tax calculations support (BC, ON or US). No other jurisdiction is substituted and no tax is assumed.',{ps:String(ps)});
    return res;
  }
  if(![out.grossRevenue, out.hardCost, out.softCost].every(Number.isFinite)){
    res.e51 = { status:'unavailable' };
    note('tax.inputsIncomplete','Tax not calculated: revenue or cost inputs are incomplete.');
  } else {
    try{
      const req = { jurisdiction:region, totalRevenueFromSales:out.grossRevenue, hardCosts:out.hardCost, softCosts:out.softCost };
      if(region==='CA') req.province = ps;
      const dp = TAX.developerProfit(req);
      // No rate is passed, so the engine's afterTaxProfit/effectiveTaxRate are never read or kept.
      res.e51 = { status:'partial', jurisdiction:region, province:region==='CA'?ps:null, preTax:dp.preMinusTaxProfit };
    }catch(e){ res.e51 = { status:'error', message:e.message }; }
    note('tax.e51Basis',"E51's pre-tax figure is gross sales minus hard and soft costs only. It excludes land, contingency, sales commissions and financing, so it is not Project Profit and not taxable income.");
    if(region==='CA') note('tax.e51Province','E51 only distinguishes Canada from the US. The selected province is recorded but does not change the E51 result.');
    note('tax.e51AfterTaxWithheld',"No after-tax figure is shown for any jurisdiction: the taxable-profit basis and the applicable tax rate are not established, so applying a rate to E51's pre-tax arithmetic would not be a tax estimate.");
  }
  if(region==='CA'){
    if(![out.hardCost, out.softCost, i.unitsTotal].every(Number.isFinite) || i.unitsTotal<0){
      res.e52 = { status:'unavailable' };
    } else {
      try{
        const g = TAX.gstHstDevCharges({ jurisdiction:'CA', province:ps, constructionCosts:out.hardCost+out.softCost, unitCount:i.unitsTotal, unitType:'residential', gstHstRegistered:true });
        res.e52 = { status:'partial', province:ps, gstHstRate:g.gstHstRate, netGstHstOwing:g.netGstHstOwing, totalDevCharges:g.totalDevCharges, devChargeRatePerUnit:g.devChargeRatePerUnit };
        note('tax.e52Gst','E52 applies the {province} combined GST/HST rate ({rate}) to hard + soft costs under one scenario: GST/HST-registered developer, residential units. Under that scenario input tax credits offset the charge, so net GST/HST owing is $0. This does not establish that all of the project\'s GST/HST obligations are zero.',{province:ps, rate:+(g.gstHstRate*100).toFixed(3)+'%'});
        note('tax.e52Dev','Development charges are a {province}-level screening allowance (engine default per unit × units). They are not verified for any municipality and do not capture all municipal fees.',{province:ps});
        note('tax.e52NotInE51',"The allowance is not added to the budget or to E51's costs; it is not established whether the soft-cost budget already includes such charges.");
      }catch(e){ res.e52 = { status:'error', message:e.message }; }
    }
  } else {
    res.e52 = { status:'notApplicable' };
    note('tax.usNoState','US is a country-level selection with no state chosen, so no state-specific tax (transfer, excise, impact fees or state income tax) is calculated.');
  }
  return res;
}
module.exports = { DEV_TAX_JURISDICTIONS, devstudioTaxApplicability };
