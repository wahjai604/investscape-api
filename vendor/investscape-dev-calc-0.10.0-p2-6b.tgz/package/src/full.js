'use strict';
/**
 * Full (Development Studio) single-phase calculation, P2-2B.
 *
 * Mechanically relocated from buildFinancingFacilities() and devstudioCompute() in investscape-v2-remastered.html
 * (reference SHA-256 84cf6e13...c193c83). The function bodies are byte-identical to the page except for two
 * documented edits to devstudioCompute:
 *   1. the signature takes explicit inputs and injected engines:  devstudioCompute(i, deps)  with deps.CALC,
 *      replacing  devstudioCompute(overrideInputs)  and its  i = overrideInputs || state.devstudio.inputs  fallback;
 *   2. the page-global CALC reference becomes  const CALC = deps.CALC.
 * There is NO state fallback: i must be supplied (the page falls back to state when i is falsy; the module throws a TypeError).
 *
 * RAW LEGACY BEHAVIOUR, preserved on purpose (strict parity gate): no validation, no coercion, no status. NaN, Infinity,
 * undefined and string concatenation flow through exactly as on the page. Calls to CALC.calculateFinancingTable,
 * calculateBudgetRollup, calculateSourcesUses and calculateAcquisitionStructure that throw become null fields; a throw from
 * CALC.calculateCapitalStack, or from the inline arithmetic, propagates unchanged.
 * Hard-coded assumptions kept as is: 5% commission, equity rate 0.20, tax rate 0.27 in the capital stack, 25-year senior
 * amortisation, 0.5 ha parcels in the E82 call.
 *
 * Dependencies: ONLY the calc engine (CALC), injected by the caller. No state, DOM, formatting, translation, clock,
 * storage, economic engine or tax engine. The engine bundle is not part of this package.
 * Basis: Full single-phase (TDC excludes financing; revenue net of the fixed 5% commission). Not the Quick basis.
 */
function buildFinancingFacilities(i, tdc){
  const loanAmount = tdc * (i.ltcPct/100);
  const facilities = [];
  const seniorInterestReserve = loanAmount * (i.interestReservePercent/100) * (i.constructionMonths/12) * (i.financingRate/100) * i.withdrawalFactor;
  // Phase 2c: senior facility with interest-only bullet repayment (real
  // construction-loan mechanic) when seniorRepaymentType is set to it. Falls
  // back to amortizing (25-year term) when omitted or set to "amortizing".
  const seniorObj = {
    id:'senior', type:'senior_debt', amount:loanAmount, rate:i.financingRate/100, amortizationYears:25,
    loanToCost: i.ltcPct/100,
    interestReserveAmount: seniorInterestReserve,
    commitmentFeePercent: i.commitmentFeePercent/100
  };
  if(i.seniorRepaymentType === 'interest_only_bullet'){
    seniorObj.repaymentType = 'interest_only_bullet';
    seniorObj.bulletRepaymentMonth = Math.max(1, i.constructionMonths + (i.sellOffMonths||0));
  }
  facilities.push(seniorObj);
  if(i.mezzAmount > 0){
    const mezzObj = {
      id:'mezz', type:'mezzanine', amount:i.mezzAmount, rate:i.mezzRate/100, amortizationYears:i.mezzAmortizationYears,
      drawMonth: Math.max(0, Math.round(i.mezzDrawMonth||0)),
      commitmentFeePercent: i.commitmentFeePercent/100
    };
    if(i.mezzRepaymentType === 'interest_only_bullet'){
      mezzObj.repaymentType = 'interest_only_bullet';
      mezzObj.bulletRepaymentMonth = Math.max(1, i.constructionMonths + (i.mezzSellOffMonths||0));
    }
    facilities.push(mezzObj);
  }
  if(i.presaleDepositAmount > 0){
    // Presale deposits held in trust, released in one bullet at the milestone
    // month set below — real trust-release mechanic (E2 buildPresaleDepositSchedule).
    // Item 8 (Aug 24 2026) fix: this facility accrues ZERO interest. A presale
    // deposit is buyer earnest money sitting in the developer's lawyer's trust
    // account as proof of demand for the bank's construction-loan gate — it is
    // NOT a loan the developer has drawn, and the developer pays no interest on
    // it; it nets against the buyer's final purchase price at completion.
    // `rate` is still set below for backward compatibility with the tranche
    // shape but is deliberately not read for interest purposes (matches the
    // real engine's buildPresaleDepositSchedule() fix — see the Presale Gate
    // Rework design doc). Previously this facility was (incorrectly) charged
    // interest at the project's financingRate — that overstated financing cost.
    facilities.push({
      id:'presale', type:'presale_deposit', amount:i.presaleDepositAmount, rate:i.financingRate/100,
      milestones:[{ month:0, cumulativeReleasePercent:0 }, { month:Math.max(1,Math.round(i.presaleDepositMilestoneMonth)), cumulativeReleasePercent:1 }]
    });
  }
  return facilities;
}
function devstudioCompute(i, deps){
  const CALC = deps.CALC;
  const hardCost = i.hardCostPsf * i.buildableSf;
  const softCost = hardCost * (i.softCostPct/100);
  const contingency = (hardCost+softCost) * (i.contingencyPct/100);
  const tdc = i.landCost + hardCost + softCost + contingency;
  const grossRevenue = i.avgUnitPrice * i.unitsTotal;
  const commissions = grossRevenue * 0.05;
  const netRevenue = grossRevenue - commissions;
  const profit = netRevenue - tdc;
  const marginOnCost = profit / tdc;
  const loanAmount = tdc * (i.ltcPct/100);
  // Batch F (E78): real multi-facility array — senior always present, mezz/
  // presale-deposit additive when their state amount is > 0.
  const facilities = buildFinancingFacilities(i, tdc);
  const totalDebtFacilities = facilities.reduce((s,f)=>s+f.amount,0);
  const equity = Math.max(0, tdc - totalDebtFacilities);
  const stack = CALC.calculateCapitalStack([
    ...facilities.map(f=>({ type:f.type, amount:f.amount, rate:f.rate })),
    { type:'equity', amount:equity, rate:0.20 }
  ], 0.27);
  // Batch F (E78): combined financing table — sources, per-facility interest
  // reserve draw-down, and a period-by-period combined balance series.
  // Phase 2c: extend the chart's timeline to cover all active facilities'
  // bullet repayment points (not just constructionMonths), so the chart shows
  // the full payoff event for each facility, not a truncated view. E.g. senior
  // draws month 1 and repays at month 30 (construction + sell-off), mezzanine
  // draws month 6 and repays at month 28 — the chart needs to run through
  // month 30 to show both transitions.
  let timelineMonths = Math.max(1, Math.round(i.constructionMonths));
  for(const f of facilities){
    if(f.repaymentType === 'interest_only_bullet' && f.bulletRepaymentMonth){
      timelineMonths = Math.max(timelineMonths, f.bulletRepaymentMonth);
    }
    if(f.type === 'presale_deposit'){
      // Presale facility's repayment is at its milestone month
      timelineMonths = Math.max(timelineMonths, Math.max(1, Math.round(i.presaleDepositMilestoneMonth)));
    }
  }
  let financingTable = null;
  try{ financingTable = CALC.calculateFinancingTable({ facilities, months: timelineMonths }); }
  catch(e){ financingTable = null; }
  // Batch F (E80): itemized budget vs. actuals, using the same four cost
  // buckets the existing donut chart already shows (Land/Hard/Soft/Contingency)
  // — actual/committed % fields are real editable state (Project Inputs →
  // Budget seed values above), not invented per line.
  const budgetLineItems = [
    { category:'Land', description:'Land acquisition', budgetedAmount:i.landCost, actualAmount:i.landCostActual, committedAmount:i.landCostCommitted, isContingencyLine:false },
    { category:'Hard Costs', description:'Construction hard costs', budgetedAmount:hardCost, actualAmount:hardCost*(i.hardCostActualPct/100), committedAmount:hardCost*(i.hardCostCommittedPct/100), isContingencyLine:false },
    { category:'Soft Costs', description:'Design, permits, consultants', budgetedAmount:softCost, actualAmount:softCost*(i.softCostActualPct/100), committedAmount:softCost*(i.softCostCommittedPct/100), isContingencyLine:false },
    { category:'Contingency', description:'Construction contingency reserve', budgetedAmount:contingency, actualAmount:contingency*(i.contingencyActualPct/100), committedAmount:0, isContingencyLine:true }
  ];
  let budgetAnalysis = null;
  try{ budgetAnalysis = CALC.calculateBudgetRollup(budgetLineItems); }
  catch(e){ budgetAnalysis = null; }
  // Batch F (E81): Sources ≡ Uses. financingCosts intentionally omitted so
  // E81 derives it from `facilities` itself (Σ interest reserve + Σ
  // commitment fee via calculateCapitalStack) rather than duplicating that
  // math here — the documented integration point in E81's own types.
  // sponsorEquityAmount is real, separately-tracked state (not re-derived
  // from `equity` above) — if it doesn't match the computed equity gap,
  // that's a real, honest reconciliation mismatch E81 will flag, not hidden.
  let sourcesUses = null;
  try{
    sourcesUses = CALC.calculateSourcesUses({
      uses:{ landAcquisitionCost:i.landCost, hardCosts:hardCost, softCosts:softCost, contingency },
      facilities,
      sponsorEquityAmount:i.sponsorEquityAmount
    });
  }catch(e){ sourcesUses = null; }
  // Batch F (E82): acquisition structure (multi-parcel assembly + asset-
  // purchase vs. bare-trust), BC only per E11's existing scope. Single
  // parcel by default (mirrors the Land tab's existing PTT input exactly);
  // a second parcel/bare-trust are opt-in via Project Inputs.
  let acquisitionStructureResult = null;
  if(i.provinceState==='BC'){
    try{
      const parcels = [{ id:'parcel-1', purchasePrice:i.landCost, fmv:i.landCost, propertySize_hectares:0.5, hasSecondaryBuilding:false }];
      if(i.multiParcelAssembly && i.parcel2Price>0){
        parcels.push({ id:'parcel-2', purchasePrice:i.parcel2Price, fmv:i.parcel2Fmv||i.parcel2Price, propertySize_hectares:0.5, hasSecondaryBuilding:false });
      }
      acquisitionStructureResult = CALC.calculateAcquisitionStructure({
        parcels, country:'Canada', province:'BC', acquisitionStructure:i.acquisitionType,
        isFTHB:false, isPrincipalResidence:false
      });
    }catch(e){ acquisitionStructureResult = null; }
  }
  return { hardCost, softCost, contingency, tdc, grossRevenue, commissions, netRevenue, profit, marginOnCost, loanAmount, equity, stack, facilities, financingTable, budgetAnalysis, sourcesUses, acquisitionStructureResult };
}

module.exports = { buildFinancingFacilities, devstudioCompute };
