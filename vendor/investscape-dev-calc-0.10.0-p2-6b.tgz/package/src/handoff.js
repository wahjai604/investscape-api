'use strict';
/**
 * Quick -> Full handoff MAPPING, P2-2F.
 *
 * Mechanically relocated from investscape-v2-remastered.html (reference SHA-256 84cf6e13...c193c83): quickToFullHandoffPlan() and
 * the constants it reads (HANDOFF_FULL_PROVINCE_STATES, HANDOFF_QUICK_VALUE_MAX, HANDOFF_NOT_CARRIED_KEYS) plus the two reference
 * lists it consults (CITY_OPTIONS, DEV_BUILDING_SUBTYPES).
 *
 * Interface: quickToFullHandoffPlan(deal, extra, config = HANDOFF_CONFIG). The configuration is EXPLICIT: it is an argument, and
 * the default is HANDOFF_CONFIG, an immutable (deeply frozen) snapshot of the page's lists, identified by
 * HANDOFF_CONFIG.identity ({ configVersion, sourceReferenceHtmlSha256 }) and by a content hash recorded in the parity golden.
 * The snapshot is NOT refreshed from any newer list: accepted identifiers are exactly those on the reference page. A caller that
 * wants other lists must pass its own config (not parity-tested here).
 *
 * Edits relative to the page text, all at the boundary: the signature gains the third argument `config`; the page-global constants
 * become reads of `config` (HANDOFF_FULL_PROVINCE_STATES -> config.fullProvinceStates, HANDOFF_QUICK_VALUE_MAX ->
 * config.quickValueMax, HANDOFF_NOT_CARRIED_KEYS -> config.notCarriedKeys, CITY_OPTIONS -> config.cityOptions,
 * DEV_BUILDING_SUBTYPES -> config.buildingSubtypes). Statement order and logic are otherwise identical.
 *
 * Mapping only. No state, DOM, engine, clock, translation, storage, project creation, timestamps, persistence, notices, navigation
 * or rollback. Native validation is a later adapter slice: the raw coercions are preserved on purpose (Number() coercion of the
 * price and soft cost, trim + upper-case + 80-character truncation of the jurisdiction, an accepted number jurisdiction such as 5
 * becoming the text "5", and exact-match membership of market and subtype identifiers).
 */
const deepFreeze = v => { if (v && typeof v === 'object') { for (const k of Object.keys(v)) deepFreeze(v[k]); Object.freeze(v); } return v; };

const HANDOFF_CONFIG = deepFreeze({
  identity: { configVersion: 'page-lists-1', sourceReferenceHtmlSha256: '84cf6e13043fe392e8c4a9f82e37ba90ec68b86f948c8f91082bcc9810193c83' },
  fullProvinceStates: ['BC','ON','US'],
  quickValueMax: 80,
  notCarriedKeys: ['grossSelloutValue','constructionCostTotal','requiredProfitMarginPct','buildableSf','holdPeriodYears'],
  cityOptions: [
    ['vancouver-bc','Vancouver','BC','west-coast-canada'],['victoria-bc','Victoria','BC','west-coast-canada'],
    ['calgary-ab','Calgary','AB','prairie-canada'],['edmonton-ab','Edmonton','AB','prairie-canada'],
    ['toronto-on','Toronto','ON','central-canada'],['ottawa-on','Ottawa','ON','central-canada'],
    ['halifax-ns','Halifax','NS','atlantic-canada'],
    ['austin-tx','Austin','TX','us-south'],['houston-tx','Houston','TX','us-south'],['miami-fl','Miami','FL','us-south'],
    ['seattle-wa','Seattle','WA','us-west'],['phoenix-az','Phoenix','AZ','us-west']
  ],
  buildingSubtypes: [
    ['condo_up_to_12','Condo/apartment — up to 12 storeys'],
    ['condo_13_39','Condo/apartment — 13-39 storeys'],
    ['condo_40_60','Condo/apartment — 40-60 storeys'],
    ['townhouse_wood','Row townhouse (wood-framed)'],
    ['sfr_wood','Single-family residential (wood-framed)'],
    ['office_class_b_under5','Office — Class B, under 5 storeys'],
    ['office_class_a_5_30','Office — Class A, 5-30 storeys'],
    ['retail_strip','Retail — strip plaza'],
    ['retail_bigbox','Retail — big box store'],
    ['industrial_warehouse','Industrial — warehouse']
  ]
});

function quickToFullHandoffPlan(deal, extra, config = HANDOFF_CONFIG){
  const inputs = {};
  const price = Number(deal && deal.purchasePrice);
  if(isFinite(price) && price > 0) inputs.landCost = price;
  // Jurisdiction: the trimmed, upper-cased value must be exactly one the Dev
  // Studio select offers. Nothing is inferred from market, address or text, and
  // a US state (AZ, TX...) is NOT mapped to 'US'. The original text is kept so
  // the notice can say what Quick held when nothing was transferred.
  const rawProv = extra ? extra.provinceState : '';
  const quickJurisdiction = (typeof rawProv==='string' || typeof rawProv==='number') ? String(rawProv).trim().slice(0, config.quickValueMax) : '';
  const prov = quickJurisdiction.toUpperCase();
  if(config.fullProvinceStates.includes(prov)) inputs.provinceState = prov;
  if(extra && config.cityOptions.some(c=>c[0]===extra.marketId)) inputs.marketId = extra.marketId;
  if(extra && config.buildingSubtypes.some(s=>s[0]===extra.buildingSubtype)) inputs.buildingSubtype = extra.buildingSubtype;
  const soft = Number(extra && extra.softCostPct);
  if(extra && extra.softCostPct !== '' && extra.softCostPct != null && isFinite(soft) && soft >= 0) inputs.softCostPct = soft;
  return { inputs, notCarriedKeys: config.notCarriedKeys.slice(), quickJurisdiction };
}
module.exports = { HANDOFF_CONFIG, quickToFullHandoffPlan };
