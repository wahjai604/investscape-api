'use strict';
/**
 * Quick calculation integration ADAPTER (P2-4A), contract "quick-adapter-1".
 *
 * A transport-neutral wrapper around the extracted calcQuick() for future native use. It is NEW adapter policy; calcQuick itself and its
 * raw legacy behaviour are unchanged and still exported separately. No DOM, WeWeb globals, storage, network, formatting, translation
 * or clock; no engine. Pure functions of their arguments (the optional `deps.calcQuick` is a test seam).
 *
 * REQUEST   { contractVersion:'quick-adapter-1', mode:'quick', inputRevision:<non-empty string | finite number>,
 *             inputs:{ purchasePrice, holdPeriodYears, constructionCostTotal, softCostPct, grossSelloutValue, requiredProfitMarginPct } }
 * RESULT    { contractVersion, kind:'result', mode, inputRevision, inputIdentity, calculationPackageVersion,
 *             status:'ok'|'incomplete'|'invalid'|'unavailable'|'error', issues:[{field,code,category}], unavailableFields:[],
 *             calculationError:null|{name,message}, normalizedInputs:null|{...six numbers}, raw:null|{ the seven calcQuick outputs },
 *             disclosures:[{code,text}] }
 *
 * INPUT POLICY (adapter policy for this slice, NOT legacy behaviour):
 *   - a finite number, or a non-blank string that is plain decimal numeric text (optional sign, digits, optional fraction, optional
 *     exponent; no thousands separators, currency symbols, hex or words), is accepted and converted with Number();
 *   - zero is accepted as supplied (except where a rule below requires positive); -0 is accepted and kept;
 *   - missing, null, undefined and whitespace-only strings are INCOMPLETE (never silently zero);
 *   - booleans, arrays, objects, functions, symbols, bigints, non-numeric text and non-finite numbers (NaN, +/-Infinity, and text that
 *     overflows to Infinity) are INVALID, before calcQuick is called;
 *   - holdPeriodYears must be > 0; purchasePrice, constructionCostTotal, grossSelloutValue, softCostPct and requiredProfitMarginPct must
 *     be >= 0 (negative is invalid); total cost (purchasePrice + constructionCostTotal + soft costs) must be > 0;
 *   - no upper limits, no currency or FX model; percentages are whole percent (22 means 22%); unknown extra input keys are ignored.
 * STATUS: 'invalid' when any invalid issue exists (even if others are incomplete); else 'incomplete' when any required value is missing;
 *   else the calculation runs: 'error' if calcQuick threw (a calculation error, distinct from input errors), 'unavailable' when any
 *   output number is not finite (no raw results are offered; the affected fields are listed), otherwise 'ok'.
 * Raw outputs for valid inputs are EXACTLY calcQuick(deal, extra) of the normalized numbers.
 */
const { calcQuick } = require('./quick');
const { PACKAGE_VERSION } = require('./version');

const QUICK_ADAPTER_CONTRACT_VERSION = 'quick-adapter-1';
const QUICK_FIELDS = Object.freeze(['purchasePrice', 'holdPeriodYears', 'constructionCostTotal', 'softCostPct', 'grossSelloutValue', 'requiredProfitMarginPct']);
const NONNEGATIVE = Object.freeze(['purchasePrice', 'constructionCostTotal', 'grossSelloutValue', 'softCostPct', 'requiredProfitMarginPct']);
const RAW_NUMERIC_OUTPUTS = Object.freeze(['totalCost', 'grossSelloutValue', 'residualLandValue', 'landCost', 'returnOnCost', 'simpleIrr']);
const NUMERIC_TEXT = /^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/;

const DISCLOSURES = Object.freeze([
  Object.freeze({ code: 'quick.screening', text: 'Quick is a screening calculation, not a development appraisal. It is a different basis from the Full development calculation and the two are not unified.' }),
  Object.freeze({ code: 'quick.revenueBasis', text: 'Revenue is the gross sellout value you enter as a single total. No sales commissions, taxes or price assumptions are applied to it.' }),
  Object.freeze({ code: 'quick.requiredMarginBasis', text: 'The required profit margin is a percentage of gross sellout value (not of cost) and is used only for the residual land value. Full uses a return on cost, which is a different basis.' }),
  Object.freeze({ code: 'quick.softCostBasis', text: 'Soft costs are the soft-cost percentage applied to the construction cost total only.' }),
  Object.freeze({ code: 'quick.returnOnCostBasis', text: 'Return on cost is actual profit divided by total cost, where total cost is land plus construction plus soft costs. Financing, taxes, contingency and commissions are not included.' }),
  Object.freeze({ code: 'quick.simpleAnnualisedReturn', text: 'The annualised return is a simple compound annualisation of profit over total cost across the hold period, as one lump sum with no cash-flow timing. The hold period used is never less than 0.5 years.' }),
  Object.freeze({ code: 'quick.noTaxFinancingCurrency', text: 'No taxes, financing or currency conversion are included. All amounts are in the single currency you entered.' }),
  Object.freeze({ code: 'quick.notAudited', text: 'This result has not been audited and is not tax advice or a statement of production readiness.' })
]);

const isPlainObject = v => v !== null && typeof v === 'object' && !Array.isArray(v);
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);

/** Normalizes one supplied value: { state:'ok', value } | { state:'incomplete', code } | { state:'invalid', code }. */
function normalizeNumber(v) {
  if (v === undefined) return { state: 'incomplete', code: 'missing' };
  if (v === null) return { state: 'incomplete', code: 'null' };
  if (typeof v === 'number') return Number.isFinite(v) ? { state: 'ok', value: v } : { state: 'invalid', code: 'notFinite' };
  if (typeof v === 'string') {
    const s = v.trim();
    if (s === '') return { state: 'incomplete', code: 'blank' };
    if (!NUMERIC_TEXT.test(s)) return { state: 'invalid', code: 'notNumeric' };
    const n = Number(s);
    return Number.isFinite(n) ? { state: 'ok', value: n } : { state: 'invalid', code: 'notFinite' };
  }
  return { state: 'invalid', code: 'wrongType' };
}
const repr = n => (Object.is(n, -0) ? '-0' : String(n));

/** Per-field normalization of a request's inputs (also used for the identity). */
function normalizeInputs(inputs) {
  const out = {};
  for (const f of QUICK_FIELDS) out[f] = isPlainObject(inputs) ? normalizeNumber(has(inputs, f) ? inputs[f] : undefined) : { state: 'invalid', code: 'inputsNotObject' };
  return out;
}
function identityOf(norm) {
  const tok = f => { const n = norm[f]; return n.state === 'ok' ? 'n:' + repr(n.value) : n.state + ':' + n.code; };
  return [QUICK_ADAPTER_CONTRACT_VERSION, 'quick'].concat(QUICK_FIELDS.map(f => f + '=' + tok(f))).join('|');
}
/** Deterministic input identity: a self-describing canonical string of the NORMALIZED inputs (numeric strings and numbers that are equal give the same identity; the revision is not part of it). */
function quickInputIdentity(inputs) { return identityOf(normalizeInputs(inputs)); }

function revisionOf(rev) {
  if (rev === undefined || rev === null) return { ok: false, issue: { field: 'inputRevision', code: rev === null ? 'null' : 'missing', category: 'incomplete' } };
  if (typeof rev === 'string') return rev.trim() === '' ? { ok: false, issue: { field: 'inputRevision', code: 'blank', category: 'incomplete' } } : { ok: true, value: rev };
  if (typeof rev === 'number' && Number.isFinite(rev)) return { ok: true, value: rev };
  return { ok: false, issue: { field: 'inputRevision', code: 'wrongType', category: 'invalid' } };
}

function emptyResult(request, revision, identity, status, issues) {
  return {
    contractVersion: QUICK_ADAPTER_CONTRACT_VERSION, kind: 'result', mode: 'quick',
    inputRevision: revision.ok ? revision.value : null, inputIdentity: identity, calculationPackageVersion: PACKAGE_VERSION,
    status, issues, unavailableFields: [], calculationError: null, normalizedInputs: null, raw: null,
    disclosures: DISCLOSURES.map(d => ({ code: d.code, text: d.text }))
  };
}

function quickCalculate(request, deps) {
  const calc = (deps && deps.calcQuick) || calcQuick;
  const req = isPlainObject(request) ? request : null;
  const issues = [];
  if (!req) issues.push({ field: 'request', code: 'wrongType', category: 'invalid' });
  const revision = req ? revisionOf(req.inputRevision) : { ok: false };
  if (req) {
    if (!revision.ok) issues.push(revision.issue);
    if (req.contractVersion === undefined || req.contractVersion === null) issues.push({ field: 'contractVersion', code: 'missing', category: 'incomplete' });
    else if (req.contractVersion !== QUICK_ADAPTER_CONTRACT_VERSION) issues.push({ field: 'contractVersion', code: 'unsupported', category: 'invalid' });
    if (req.mode === undefined || req.mode === null) issues.push({ field: 'mode', code: 'missing', category: 'incomplete' });
    else if (req.mode !== 'quick') issues.push({ field: 'mode', code: 'unsupported', category: 'invalid' });
    if (req.inputs === undefined || req.inputs === null) issues.push({ field: 'inputs', code: 'missing', category: 'incomplete' });
    else if (!isPlainObject(req.inputs)) issues.push({ field: 'inputs', code: 'wrongType', category: 'invalid' });
  }
  const norm = normalizeInputs(req ? req.inputs : undefined);
  const identity = identityOf(norm);
  if (req && isPlainObject(req.inputs)) {
    for (const f of QUICK_FIELDS) {
      const n = norm[f];
      if (n.state !== 'ok') { issues.push({ field: f, code: n.code, category: n.state }); continue; }
      if (f === 'holdPeriodYears') { if (!(n.value > 0)) issues.push({ field: f, code: 'notPositive', category: 'invalid' }); }
      else if (NONNEGATIVE.includes(f) && n.value < 0) issues.push({ field: f, code: 'negative', category: 'invalid' });
    }
    const cost = ['purchasePrice', 'constructionCostTotal', 'softCostPct'].map(f => norm[f]);
    if (cost.every(n => n.state === 'ok' && n.value >= 0)) {
      const [p, c, s] = cost.map(n => n.value);
      if (!(p + c + c * (s / 100) > 0)) issues.push({ field: 'totalCost', code: 'notPositive', category: 'invalid' });
    }
  }
  if (issues.length) return emptyResult(req, revision, identity, issues.some(i => i.category === 'invalid') ? 'invalid' : 'incomplete', issues);

  const v = {}; for (const f of QUICK_FIELDS) v[f] = norm[f].value;
  const res = emptyResult(req, revision, identity, 'ok', []);
  res.normalizedInputs = Object.assign({}, v);
  let raw;
  try {
    raw = calc({ purchasePrice: v.purchasePrice, holdPeriodYears: v.holdPeriodYears }, { constructionCostTotal: v.constructionCostTotal, softCostPct: v.softCostPct, grossSelloutValue: v.grossSelloutValue, requiredProfitMarginPct: v.requiredProfitMarginPct });
  } catch (e) {
    res.status = 'error'; res.calculationError = { name: String(e && e.name), message: String(e && e.message) }; return res;
  }
  const bad = isPlainObject(raw) ? RAW_NUMERIC_OUTPUTS.filter(k => raw[k] !== null && !(typeof raw[k] === 'number' && Number.isFinite(raw[k]))) : ['result'];
  if (bad.length) { res.status = 'unavailable'; res.unavailableFields = bad; return res; }
  res.raw = Object.assign({}, raw);
  return res;
}

/**
 * Pure FRESHNESS test: does `result` belong to the CURRENT `request` and was it produced by the CURRENT adapter/package version?
 * Requires result.kind === 'result', the contract version, mode, input revision (strict equality), input identity and
 * result.calculationPackageVersion === PACKAGE_VERSION. It deliberately does NOT look at result.status: invalid, incomplete,
 * unavailable and error results stay matchable so their messages can be displayed.
 * IMPORTANT: a match establishes freshness only. It is NOT permission to display raw values: consumers must separately check
 * result.status === 'ok' before using result.raw.
 */
function quickResultMatchesRequest(result, request) {
  if (!isPlainObject(result) || !isPlainObject(request)) return false;
  const rev = revisionOf(request.inputRevision);
  if (!rev.ok) return false;
  return result.kind === 'result' && result.calculationPackageVersion === PACKAGE_VERSION && result.contractVersion === QUICK_ADAPTER_CONTRACT_VERSION && result.mode === 'quick' && request.mode === 'quick' && request.contractVersion === QUICK_ADAPTER_CONTRACT_VERSION
    && result.inputRevision === rev.value && typeof result.inputIdentity === 'string' && result.inputIdentity === quickInputIdentity(request.inputs);
}
module.exports = { QUICK_ADAPTER_CONTRACT_VERSION, QUICK_FIELDS, QUICK_DISCLOSURES: DISCLOSURES, quickCalculate, quickInputIdentity, quickResultMatchesRequest };
