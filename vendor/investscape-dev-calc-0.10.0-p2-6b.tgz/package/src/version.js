'use strict';
/** Single source of the calculation package version (must equal package.json "version"; a test checks it). */
module.exports = { PACKAGE_VERSION: '0.10.0-p2-6b' };
