'use strict';
/**
 * Single-phase residual land value solver, P2-2C.
 *
 * Mechanically relocated from solveRLVWithFinancing() in investscape-v2-remastered.html (reference SHA-256
 * 84cf6e13...c193c83). The body is byte-identical to the page except for the documented boundary edits:
 *   1. the signature gains an explicit third argument  deps  (carrying the injected calc engine, deps.CALC);
 *   2. the two calls  devstudioCompute(x)  become  devstudioCompute(x, deps)  and use the extracted Full calculation.
 * Nothing else changed: initial estimate (financing-excluded linear value), target convention (targetMarginPct is a whole
 * percent of total cost, m = target/100), financing-INCLUSIVE basis (financing cost taken from sourcesUses.uses.financingCosts
 * at the trial land cost), at most 20 iterations, $10 convergence threshold, the exact fallback (returns the linear value with
 * converged:false and financingCostAtSolution 0), and the error behaviour: the first devstudioCompute call propagates its
 * errors, while errors from the trial calls inside the loop are swallowed and count as financing cost 0.
 *
 * RAW LEGACY BEHAVIOUR preserved: no clamping of a negative result, no sanitising of NaN/Infinity, no validation. The
 * baseInputs.requiredProfitMarginPct field is NOT read here; the target is the second argument.
 * Basis: single-phase financing-inclusive RLV. It is NOT the staged per-stage RLV (financing-excluded) in computeStagedRollup.
 */
const { devstudioCompute } = require('./full');

function solveRLVWithFinancing(baseInputs, targetMarginPct, deps){
  const m = (targetMarginPct||0)/100;
  const maxIterations = 20;
  const toleranceDollars = 10;
  const out0 = devstudioCompute(baseInputs, deps);
  const K = out0.hardCost + out0.softCost + out0.contingency; // independent of landCost
  const linearMaxLandCost = (out0.netRevenue/(1+m)) - K; // old formula, kept for comparison/fallback
  let landCostGuess = linearMaxLandCost;
  let financingCostAtSolution = 0;
  let converged = false;
  let iterations = 0;
  for(let iter=0; iter<maxIterations; iter++){
    iterations = iter+1;
    const testInputs = { ...baseInputs, landCost: Math.max(0, landCostGuess) };
    let financingCost = 0;
    try{
      const testOut = devstudioCompute(testInputs, deps);
      if(testOut.sourcesUses && testOut.sourcesUses.uses && typeof testOut.sourcesUses.uses.financingCosts === 'number'){
        financingCost = testOut.sourcesUses.uses.financingCosts;
      }
    }catch(e){ financingCost = 0; }
    const newLandCostGuess = (out0.netRevenue/(1+m)) - K - financingCost;
    if(Math.abs(newLandCostGuess - landCostGuess) < toleranceDollars){
      landCostGuess = newLandCostGuess; financingCostAtSolution = financingCost; converged = true; break;
    }
    landCostGuess = newLandCostGuess;
    financingCostAtSolution = financingCost;
  }
  if(!converged){
    // Documented safety fallback — never surface a non-converged number.
    return { maxLandCost: linearMaxLandCost, financingCostAtSolution: 0, iterations, converged: false, kExcludingFinancing: K, linearMaxLandCost };
  }
  return { maxLandCost: landCostGuess, financingCostAtSolution, iterations, converged: true, kExcludingFinancing: K, linearMaxLandCost };
}

module.exports = { solveRLVWithFinancing };
