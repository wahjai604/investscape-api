'use strict';
/**
 * Full (single-phase) calculation integration ADAPTER (P2-6B), contract "full-adapter-1".
 *
 * A transport-neutral, validating wrapper around the extracted devstudioCompute(). NEW adapter policy: devstudioCompute and its raw
 * legacy behaviour are unchanged and still exported separately. It wraps ONLY devstudioCompute: it never calls RLV, staged, tax, handoff
 * or E85. No DOM, WeWeb globals, storage, network, formatting, translation or clock. The calc engine is injected (deps.CALC); this
 * package contains no engine bundle and the adapter never loads one.
 *
 * REQUEST  { contractVersion:'full-adapter-1', mode:'full', inputRevision:<non-empty string | finite number>, inputs:{ the 36 FULL_FIELDS } }
 * DEPS     { CALC, engineIdentity? }   (second argument, never part of the request)
 * RESULT   { contractVersion, kind:'result', mode, inputRevision, inputIdentity, calculationPackageVersion, status, issues, notes,
 *            normalizedInputs, derived, raw, sections, unavailableFields, calculationError, engine, disclosures }
 *
 * STATUS   incomplete | invalid | error | unavailable | partial | ok   (see the spec, WEWEB-FULL-ADAPTER-CONTRACT-SPEC.md, sections 2, 5)
 * PRECEDENCE (deterministic): 1 request shape/contract/mode/revision/inputs object; 2 per-field normalization and rules, in FULL_FIELDS
 *   order; 3 cross-field rules (totalCost, timeline). Any input issue stops here: `invalid` when any issue is invalid/operational, else
 *   `incomplete`; dependencies are NOT inspected. 4 only for a valid request: deps/CALC capability, then engineIdentity shape (both
 *   `error`); 5 execution (`error` if a non-nullable step threw); 6 output inspection (`unavailable` / `partial` / `ok`).
 * For ok/partial, `raw` IS the exact object devstudioCompute(normalizedInputs, { CALC }) returned: no copy, no coercion.
 */
const { devstudioCompute } = require('./full');
const { PACKAGE_VERSION } = require('./version');

const FULL_ADAPTER_CONTRACT_VERSION = 'full-adapter-1';

/** Operational (resource) limits. NOT financial assumptions. Changing a value is a contract change (bump the version). */
const FULL_OPERATIONAL_LIMITS = Object.freeze({ version: 'full-limits-1', maxMonths: 600, unit: 'months' });

const FIELD_SPEC = [
  // name, kind, rule
  ['landCost', 'num', 'nonneg'], ['provinceState', 'enum', 'province'], ['acquisitionType', 'enum', 'acquisition'], ['multiParcelAssembly', 'bool', null],
  ['parcel2Price', 'num', 'nonneg'], ['parcel2Fmv', 'num', 'nonneg'],
  ['hardCostPsf', 'num', 'nonneg'], ['buildableSf', 'num', 'nonneg'], ['softCostPct', 'num', 'nonneg'], ['contingencyPct', 'num', 'nonneg'],
  ['unitsTotal', 'num', 'nonneg'], ['avgUnitPrice', 'num', 'nonneg'],
  ['ltcPct', 'num', 'ltc'], ['financingRate', 'num', 'nonneg'], ['interestReservePercent', 'num', 'nonneg'], ['withdrawalFactor', 'num', 'fraction'],
  ['commitmentFeePercent', 'num', 'nonneg'], ['seniorRepaymentType', 'enum', 'repayment'], ['sellOffMonths', 'num', 'months'], ['sponsorEquityAmount', 'num', 'nonneg'],
  ['mezzAmount', 'num', 'nonneg'], ['mezzRate', 'num', 'nonneg'], ['mezzAmortizationYears', 'num', 'positive'], ['mezzDrawMonth', 'num', 'months'],
  ['mezzRepaymentType', 'enum', 'repayment'], ['mezzSellOffMonths', 'num', 'months'],
  ['presaleDepositAmount', 'num', 'nonneg'], ['presaleDepositMilestoneMonth', 'num', 'months'],
  ['constructionMonths', 'num', 'constructionMonths'],
  ['landCostActual', 'num', 'nonneg'], ['landCostCommitted', 'num', 'nonneg'], ['hardCostActualPct', 'num', 'nonneg'], ['hardCostCommittedPct', 'num', 'nonneg'],
  ['softCostActualPct', 'num', 'nonneg'], ['softCostCommittedPct', 'num', 'nonneg'], ['contingencyActualPct', 'num', 'nonneg']
];
const FULL_FIELDS = Object.freeze(FIELD_SPEC.map(f => f[0]));
const ENUMS = Object.freeze({
  province: Object.freeze(['BC', 'ON', 'US']),
  acquisition: Object.freeze(['asset_purchase', 'bare_trust']),
  repayment: Object.freeze(['interest_only_bullet', 'amortizing'])
});
const MONTH_FIELDS = Object.freeze(['constructionMonths', 'sellOffMonths', 'mezzSellOffMonths', 'presaleDepositMilestoneMonth', 'mezzDrawMonth']);
const ESSENTIAL_SCALARS = Object.freeze(['hardCost', 'softCost', 'contingency', 'tdc', 'grossRevenue', 'commissions', 'netRevenue', 'profit', 'marginOnCost', 'loanAmount', 'equity']);
const RAW_KEYS = Object.freeze(ESSENTIAL_SCALARS.concat(['stack', 'facilities', 'financingTable', 'budgetAnalysis', 'sourcesUses', 'acquisitionStructureResult']));
const SECTION_KEYS = Object.freeze({ financingTable: 'financingTable', budgetAnalysis: 'budgetAnalysis', sourcesUses: 'sourcesUses', acquisitionStructureResult: 'acquisitionStructureResult' });
const REQUIRED_CALC = Object.freeze(['calculateCapitalStack', 'calculateFinancingTable', 'calculateBudgetRollup', 'calculateSourcesUses', 'calculateAcquisitionStructure']);
const INSPECT_LIMITS = Object.freeze({ maxNodesPerBranch: 100000, maxDepth: 24 });
const IDENTITY_LIMITS = Object.freeze({ maxKeys: 16, maxKeyLength: 64, maxStringLength: 256 });
const NUMERIC_TEXT = /^[+-]?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?$/;
const IDENTITY_KEY = /^[A-Za-z0-9_.-]{1,64}$/;

const DISCLOSURES = Object.freeze([
  ['full.screeningBasis', 'Full single-phase basis: revenue is units times average unit price, net of a fixed 5% sales commission. Total development cost is land plus hard, soft and contingency costs and excludes financing costs. Return on cost is profit divided by that total cost. This is not the Quick basis (a lump-sum revenue with no commission or contingency).'],
  ['full.areaIsConstructionBasis', 'The buildable area entered here is the construction area used to price hard cost. It is not a zoning or regulatory floor-area figure.'],
  ['full.commission', 'The 5% sales commission is a fixed constant in the calculation, not an input.'],
  ['full.capitalStackRates', 'The capital stack uses a fixed equity rate of 0.20 and a fixed tax rate of 0.27. They are not inputs, have no stated source and are not verified. They feed the weighted average cost of capital.'],
  ['full.financingBasis', 'The senior loan is total development cost times the loan-to-cost percentage. Financing costs are derived by the calculation engine from the facilities (interest reserve and commitment fee); senior amortisation is a fixed 25 years; the presale deposit accrues no interest. Financing costs are not part of total development cost or return on cost.'],
  ['full.rlvBasis', 'Residual land value is not computed by this operation. When a separate operation provides it, single-phase residual land value is financing-inclusive, staged per-stage residual land value is financing-excluded, and neither equals the Quick residual land value (a share of sellout value).'],
  ['full.acquisitionBcOnly', 'The acquisition structure is calculated for British Columbia only and assumes a 0.5-hectare parcel for every parcel regardless of the entered site. Outside British Columbia the operation was not run; this does not mean no acquisition tax applies.'],
  ['full.taxNotIncluded', 'No tax applicability is computed by this operation. Where a separate tax operation is used later: its developer-profit figure is gross sales minus hard and soft costs only (excluding land, contingency, commissions and financing) and is not project profit or taxable income; after-tax figures are withheld; its GST/HST screening assumes a registered developer and residential units and is Canada-only.'],
  ['full.noCurrency', 'No currency or exchange-rate handling. All amounts are in the single, unstated currency entered.'],
  ['full.engineIdentity', 'The calculation engine identity is declared by the caller and is not verified here. Engine release versions are unknown.'],
  ['full.notAudited', 'This result has not been audited and is not tax or investment advice. Matching the prototype shows sameness with it, not financial or tax correctness.']
].map(([code, text]) => Object.freeze({ code, text })));

const isObjectLike = v => v !== null && typeof v === 'object';
const protoIsPlain = v => { const p = Object.getPrototypeOf(v); return p === null || Object.getPrototypeOf(p) === null; };
/** Plain data object, realm-agnostic (the injected engine may live in another JS realm). */
const isPlain = v => isObjectLike(v) && !Array.isArray(v) && protoIsPlain(v);
const has = (o, k) => Object.prototype.hasOwnProperty.call(o, k);
const repr = n => (Object.is(n, -0) ? '-0' : String(n));

function normalizeNumber(v) {
  if (v === undefined) return { state: 'incomplete', code: 'missing' };
  if (v === null) return { state: 'incomplete', code: 'null' };
  if (typeof v === 'number') return Number.isFinite(v) ? { state: 'ok', value: v } : { state: 'invalid', code: 'notFinite' };
  if (typeof v === 'string') {
    const s = v.trim();
    if (s === '') return { state: 'incomplete', code: 'blank' };
    if (!NUMERIC_TEXT.test(s)) return { state: 'invalid', code: 'notNumeric' };
    const n = Number(s);
    return Number.isFinite(n) ? { state: 'ok', value: n } : { state: 'invalid', code: 'notFinite' };
  }
  return { state: 'invalid', code: 'wrongType' };
}
function normalizeEnum(v, set) {
  if (v === undefined) return { state: 'incomplete', code: 'missing' };
  if (v === null) return { state: 'incomplete', code: 'null' };
  if (typeof v !== 'string') return { state: 'invalid', code: 'wrongType' };
  if (v.trim() === '') return { state: 'incomplete', code: 'blank' };
  return set.includes(v) ? { state: 'ok', value: v } : { state: 'invalid', code: 'notInEnum' };
}
function normalizeBool(v) {
  if (v === undefined) return { state: 'incomplete', code: 'missing' };
  if (v === null) return { state: 'incomplete', code: 'null' };
  return typeof v === 'boolean' ? { state: 'ok', value: v } : { state: 'invalid', code: 'wrongType' };
}
const normalizeField = (kind, rule, v) => kind === 'num' ? normalizeNumber(v) : kind === 'enum' ? normalizeEnum(v, ENUMS[rule]) : normalizeBool(v);
const okv = (n, expected) => n && n.state === 'ok' && (expected === undefined || n.value === expected);

/**
 * Activation predicates. A field is ACTIVE only when the raw calculation can read it; an inactive field is never validated, is
 * normalized to null and is passed to the engine as null, so malformed values in it cannot influence anything. When the controlling
 * field is itself missing/invalid the predicate cannot be evaluated: the dependent field is `unevaluated` (also null).
 * Returns 'active' | 'inactive' | 'unevaluated' per field name.
 */
function activation(n) {
  const a = {};
  const prov = n.provinceState, bc = okv(prov) ? prov.value === 'BC' : null;
  const st = bc === null ? 'unevaluated' : bc ? 'active' : 'inactive';
  a.acquisitionType = st; a.multiParcelAssembly = st;
  if (st !== 'active') { a.parcel2Price = st; a.parcel2Fmv = st; }
  else if (!okv(n.multiParcelAssembly)) { a.parcel2Price = 'unevaluated'; a.parcel2Fmv = 'unevaluated'; }
  else if (n.multiParcelAssembly.value !== true) { a.parcel2Price = 'inactive'; a.parcel2Fmv = 'inactive'; }
  else {
    a.parcel2Price = 'active';
    a.parcel2Fmv = !okv(n.parcel2Price) ? 'unevaluated' : n.parcel2Price.value > 0 ? 'active' : 'inactive';
  }
  const sr = n.seniorRepaymentType;
  a.sellOffMonths = !okv(sr) ? 'unevaluated' : sr.value === 'interest_only_bullet' ? 'active' : 'inactive';
  const mz = n.mezzAmount, mzs = !okv(mz) ? 'unevaluated' : mz.value > 0 ? 'active' : 'inactive';
  for (const f of ['mezzRate', 'mezzAmortizationYears', 'mezzDrawMonth', 'mezzRepaymentType']) a[f] = mzs;
  if (mzs !== 'active') a.mezzSellOffMonths = mzs;
  else a.mezzSellOffMonths = !okv(n.mezzRepaymentType) ? 'unevaluated' : n.mezzRepaymentType.value === 'interest_only_bullet' ? 'active' : 'inactive';
  const pd = n.presaleDepositAmount;
  a.presaleDepositMilestoneMonth = !okv(pd) ? 'unevaluated' : pd.value > 0 ? 'active' : 'inactive';
  return a;
}
const ACTIVATION_PREDICATES = Object.freeze({
  acquisitionType: "provinceState === 'BC'", multiParcelAssembly: "provinceState === 'BC'",
  parcel2Price: "provinceState === 'BC' && multiParcelAssembly === true",
  parcel2Fmv: "provinceState === 'BC' && multiParcelAssembly === true && parcel2Price > 0",
  sellOffMonths: "seniorRepaymentType === 'interest_only_bullet'",
  mezzRate: 'mezzAmount > 0', mezzAmortizationYears: 'mezzAmount > 0', mezzDrawMonth: 'mezzAmount > 0', mezzRepaymentType: 'mezzAmount > 0',
  mezzSellOffMonths: "mezzAmount > 0 && mezzRepaymentType === 'interest_only_bullet'",
  presaleDepositMilestoneMonth: 'presaleDepositAmount > 0'
});
/** parcel2Fmv is the one active field that may be blank (null). */
const OPTIONAL_WHEN_ACTIVE = Object.freeze(['parcel2Fmv']);

function normalizeAll(inputs) {
  const n = {};
  const isObj = isPlain(inputs);
  for (const [f, kind, rule] of FIELD_SPEC) n[f] = isObj ? normalizeField(kind, rule, has(inputs, f) ? inputs[f] : undefined) : { state: 'invalid', code: 'inputsNotObject' };
  const act = isObj ? activation(n) : {};
  const fields = {};
  for (const f of FULL_FIELDS) {
    const st = act[f] || 'active';
    if (st === 'active') fields[f] = n[f];
    else fields[f] = { state: st };   // inactive/unevaluated: raw text is discarded (never validated, never echoed)
  }
  return fields;
}
function tokenOf(f) {
  const t = f.state;
  if (t === 'ok') return typeof f.value === 'number' ? 'n:' + repr(f.value) : typeof f.value === 'boolean' ? 'b:' + f.value : 's:' + f.value;
  if (t === 'inactive' || t === 'unevaluated') return t;
  return t + ':' + f.code;
}
function identityOf(fields) {
  return [FULL_ADAPTER_CONTRACT_VERSION, 'full'].concat(FULL_FIELDS.map(k => {
    const f = fields[k];
    // optional active field that is blank: a single stable token whether it was missing, null or whitespace
    if (OPTIONAL_WHEN_ACTIVE.includes(k) && f.state === 'incomplete') return k + '=null';
    return k + '=' + tokenOf(f);
  })).join('|');
}
/** Deterministic input identity: canonical string of the NORMALIZED source fields (never the revision, derived data or engine identity). */
function fullInputIdentity(inputs) { return identityOf(normalizeAll(inputs)); }

function revisionOf(rev) {
  if (rev === undefined || rev === null) return { ok: false, issue: { field: 'inputRevision', code: rev === null ? 'null' : 'missing', category: 'incomplete', params: null } };
  if (typeof rev === 'string') return rev.trim() === '' ? { ok: false, issue: { field: 'inputRevision', code: 'blank', category: 'incomplete', params: null } } : { ok: true, value: rev };
  if (typeof rev === 'number' && Number.isFinite(rev)) return { ok: true, value: rev };
  return { ok: false, issue: { field: 'inputRevision', code: 'wrongType', category: 'invalid', params: null } };
}
const issue = (field, code, category, params) => ({ field, code, category, params: params === undefined ? null : params });
const limitParams = (limit, unit, value) => ({ limit, unit, value });

/** Bounded plain-data engine identity: flat object, <=16 keys, string/finite-number/boolean/null values, data properties only. Returns a frozen snapshot. */
function snapshotEngineIdentity(v) {
  if (v === undefined) return { ok: true, declared: null, canonical: null };
  if (!isPlain(v)) return { ok: false };
  if (Object.getOwnPropertySymbols(v).length) return { ok: false };
  const keys = Object.getOwnPropertyNames(v);
  if (keys.length === 0 || keys.length > IDENTITY_LIMITS.maxKeys) return { ok: false };
  const out = {};
  for (const k of keys.slice().sort()) {
    if (!IDENTITY_KEY.test(k)) return { ok: false };
    const d = Object.getOwnPropertyDescriptor(v, k);
    if (!d || !('value' in d) || !d.enumerable) return { ok: false };
    const x = d.value;
    const good = x === null || typeof x === 'boolean' || (typeof x === 'number' && Number.isFinite(x)) || (typeof x === 'string' && x.length <= IDENTITY_LIMITS.maxStringLength);
    if (!good) return { ok: false };
    out[k] = x;
  }
  return { ok: true, declared: Object.freeze(out), canonical: JSON.stringify(Object.keys(out).map(k => [k, out[k]])) };
}

function disclosureList() { return DISCLOSURES.map(d => ({ code: d.code, text: d.text })); }
function baseResult(revision, identity, status, issues, notes) {
  return {
    contractVersion: FULL_ADAPTER_CONTRACT_VERSION, kind: 'result', mode: 'full', inputRevision: revision.ok ? revision.value : null, inputIdentity: identity,
    calculationPackageVersion: PACKAGE_VERSION, status, issues, notes, normalizedInputs: null, derived: null, raw: null, sections: null, unavailableFields: [],
    calculationError: null, engine: { declared: null, declaredCanonical: null, verified: false }, disclosures: disclosureList()
  };
}

/** Raw timeline rules of buildFinancingFacilities/devstudioCompute reproduced for the pre-execution limit check (no engine involved). */
function timelineOf(v) {
  const components = { construction: Math.max(1, Math.round(v.constructionMonths)), seniorBullet: null, mezzBullet: null, presaleMilestone: null };
  let months = components.construction;
  if (v.seniorRepaymentType === 'interest_only_bullet') { components.seniorBullet = Math.max(1, v.constructionMonths + (v.sellOffMonths || 0)); months = Math.max(months, components.seniorBullet); }
  if (v.mezzAmount > 0 && v.mezzRepaymentType === 'interest_only_bullet') { components.mezzBullet = Math.max(1, v.constructionMonths + (v.mezzSellOffMonths || 0)); months = Math.max(months, components.mezzBullet); }
  if (v.presaleDepositAmount > 0) { components.presaleMilestone = Math.max(1, Math.round(v.presaleDepositMilestoneMonth)); months = Math.max(months, components.presaleMilestone); }
  return { months, components };
}

function validate(req) {
  const issues = [], notes = [];
  const revision = req ? revisionOf(req.inputRevision) : { ok: false };
  if (!req) issues.push(issue('request', 'wrongType', 'invalid'));
  else {
    if (!revision.ok) issues.push(revision.issue);
    if (req.contractVersion === undefined || req.contractVersion === null) issues.push(issue('contractVersion', 'missing', 'incomplete'));
    else if (req.contractVersion !== FULL_ADAPTER_CONTRACT_VERSION) issues.push(issue('contractVersion', 'unsupported', 'invalid'));
    if (req.mode === undefined || req.mode === null) issues.push(issue('mode', 'missing', 'incomplete'));
    else if (req.mode !== 'full') issues.push(issue('mode', 'unsupported', 'invalid'));
    if (req.inputs === undefined || req.inputs === null) issues.push(issue('inputs', 'missing', 'incomplete'));
    else if (!isPlain(req.inputs)) issues.push(issue('inputs', 'wrongType', 'invalid'));
  }
  const fields = normalizeAll(req ? req.inputs : undefined);
  const identity = identityOf(fields);
  const activeMap = (req && isPlain(req.inputs)) ? activation(fields) : {};
  let derived = null;
  if (req && isPlain(req.inputs)) {
    const L = FULL_OPERATIONAL_LIMITS;
    for (const [f, , rule] of FIELD_SPEC) {
      const st = (activeMap[f] || 'active');
      if (st !== 'active') continue;
      const n = fields[f];
      if (n.state === 'incomplete' && OPTIONAL_WHEN_ACTIVE.includes(f)) continue;
      if (n.state !== 'ok') { issues.push(issue(f, n.code, n.state)); continue; }
      const x = n.value;
      if (rule === 'nonneg') { if (x < 0) issues.push(issue(f, 'negative', 'invalid')); }
      else if (rule === 'positive') { if (!(x > 0)) issues.push(issue(f, 'notPositive', 'invalid')); }
      else if (rule === 'ltc') { if (x < 0) issues.push(issue(f, 'negative', 'invalid')); else if (x > 100) issues.push(issue(f, 'aboveMaximum', 'invalid', limitParams(100, 'percent', x))); }
      else if (rule === 'fraction') { if (x < 0) issues.push(issue(f, 'negative', 'invalid')); else if (x > 1) issues.push(issue(f, 'aboveMaximum', 'invalid', limitParams(1, 'fraction', x))); }
      else if (rule === 'months' || rule === 'constructionMonths') {
        if (rule === 'constructionMonths' && !(x > 0)) issues.push(issue(f, 'notPositive', 'invalid'));
        else if (x < 0) issues.push(issue(f, 'negative', 'invalid'));
        else if (x > L.maxMonths) issues.push(issue(f, 'exceedsOperationalLimit', 'operational', limitParams(L.maxMonths, L.unit, x)));
      }
    }
    // cross-field: total development cost (same formula as devstudioCompute) must be above zero
    const c = ['landCost', 'hardCostPsf', 'buildableSf', 'softCostPct', 'contingencyPct'].map(f => fields[f]);
    if (c.every(n => n.state === 'ok' && n.value >= 0)) {
      const [land, psf, sf, soft, cont] = c.map(n => n.value);
      const hard = psf * sf, softC = hard * (soft / 100), conting = (hard + softC) * (cont / 100);
      if (!(land + hard + softC + conting > 0)) issues.push(issue('totalCost', 'notPositive', 'invalid'));
    }
    // timeline and notes: only for an otherwise acceptable request (every contributing field is then usable and within its own limit)
    if (!issues.length) {
      const val = f => fields[f].value, on = f => activeMap[f] === 'active';
      const t = timelineOf({
        constructionMonths: val('constructionMonths'), seniorRepaymentType: val('seniorRepaymentType'), sellOffMonths: on('sellOffMonths') ? val('sellOffMonths') : null,
        mezzAmount: val('mezzAmount'), mezzRepaymentType: on('mezzRepaymentType') ? val('mezzRepaymentType') : null,
        mezzSellOffMonths: on('mezzSellOffMonths') ? val('mezzSellOffMonths') : null, presaleDepositAmount: val('presaleDepositAmount'),
        presaleDepositMilestoneMonth: on('presaleDepositMilestoneMonth') ? val('presaleDepositMilestoneMonth') : null
      });
      derived = { operationalLimitsVersion: L.version, timeline: { months: t.months, limit: L.maxMonths, unit: L.unit, components: t.components } };
      if (!(t.months <= L.maxMonths)) issues.push(issue('timelineMonths', 'exceedsOperationalLimit', 'operational', limitParams(L.maxMonths, L.unit, t.months)));
      else {
        if (on('presaleDepositMilestoneMonth') && val('presaleDepositMilestoneMonth') < 1) notes.push({ field: 'presaleDepositMilestoneMonth', code: 'raisedToMinimum', params: { minimum: 1, unit: 'months', value: val('presaleDepositMilestoneMonth') } });
        if (on('parcel2Price') && val('parcel2Price') === 0) notes.push({ field: 'parcel2Price', code: 'parcel2Ignored', params: null });
        if (on('parcel2Fmv') && (fields.parcel2Fmv.state === 'incomplete' || fields.parcel2Fmv.value === 0)) notes.push({ field: 'parcel2Fmv', code: 'fellBackToPurchasePrice', params: null });
      }
    }
  }
  return { issues, notes, revision, fields, identity, activeMap, derived };
}

/** Builds normalizedInputs (36 keys, FULL_FIELDS order). Inactive, unevaluated and blank optional fields are null. */
function normalizedFrom(fields) {
  const out = {};
  for (const f of FULL_FIELDS) out[f] = fields[f].state === 'ok' ? fields[f].value : null;
  return out;
}

/** Fail-closed walk of one output branch. Records non-finite numbers and unexpected values; never throws, never mutates, never coerces. */
function inspectBranch(root, basePath) {
  const problems = [];
  let nodes = 0, exhausted = false;
  const ancestors = new Set();
  const walk = (x, path, depth) => {
    if (exhausted) return;
    if (++nodes > INSPECT_LIMITS.maxNodesPerBranch) { exhausted = true; problems.push({ path, code: 'inspectionLimit' }); return; }
    if (depth > INSPECT_LIMITS.maxDepth) { exhausted = true; problems.push({ path, code: 'inspectionLimit' }); return; }
    if (x === null || typeof x === 'string' || typeof x === 'boolean') return;
    if (typeof x === 'number') { if (!Number.isFinite(x)) problems.push({ path, code: 'notFinite' }); return; }
    if (typeof x !== 'object') { problems.push({ path, code: 'unexpectedType' }); return; }
    if (ancestors.has(x)) { problems.push({ path, code: 'cycle' }); exhausted = true; return; }
    let keys;
    try {
      if (Array.isArray(x)) {
        ancestors.add(x);
        for (let i = 0; i < x.length && !exhausted; i++) walk(x[i], path + '[' + i + ']', depth + 1);
        ancestors.delete(x); return;
      }
      if (!protoIsPlain(x)) { problems.push({ path, code: 'unexpectedType' }); return; }
      keys = Object.keys(x);
      ancestors.add(x);
      for (const k of keys) { if (exhausted) break; const d = Object.getOwnPropertyDescriptor(x, k); if (!d || !('value' in d)) { problems.push({ path: path + '.' + k, code: 'unexpectedType' }); continue; } walk(d.value, path + '.' + k, depth + 1); }
      ancestors.delete(x);
    } catch (e) { problems.push({ path, code: 'uninspectable' }); exhausted = true; }
  };
  walk(root, basePath, 0);
  return { problems, exhausted };
}

/** Required stack/facility structure. Returns problems; independent of the generic number scan. */
function structureProblems(raw, v) {
  const p = [];
  const fac = raw.facilities, facLen = Array.isArray(fac) ? fac.length : null;
  if (facLen === null) p.push({ path: 'raw.facilities', code: 'unexpectedType' });
  else {
    const expected = 1 + (v.mezzAmount > 0 ? 1 : 0) + (v.presaleDepositAmount > 0 ? 1 : 0);
    if (facLen !== expected) p.push({ path: 'raw.facilities', code: 'unexpectedShape' });
    fac.forEach((f, i) => {
      if (!isPlain(f)) { p.push({ path: 'raw.facilities[' + i + ']', code: 'unexpectedType' }); return; }
      if (typeof f.id !== 'string' || typeof f.type !== 'string') p.push({ path: 'raw.facilities[' + i + ']', code: 'unexpectedShape' });
      for (const k of ['amount', 'rate']) if (typeof f[k] !== 'number') p.push({ path: 'raw.facilities[' + i + '].' + k, code: 'unexpectedType' });
    });
    if (facLen && !(isPlain(fac[0]) && fac[0].id === 'senior')) p.push({ path: 'raw.facilities[0]', code: 'unexpectedShape' });
  }
  const st = raw.stack;
  if (!isPlain(st) || !Array.isArray(st.tranches)) p.push({ path: 'raw.stack', code: 'unexpectedShape' });
  else {
    if (facLen !== null && st.tranches.length !== facLen + 1) p.push({ path: 'raw.stack.tranches', code: 'unexpectedShape' });
    st.tranches.forEach((t, i) => {
      if (!isPlain(t)) { p.push({ path: 'raw.stack.tranches[' + i + ']', code: 'unexpectedType' }); return; }
      for (const k of ['amount', 'rate']) if (typeof t[k] !== 'number') p.push({ path: 'raw.stack.tranches[' + i + '].' + k, code: 'unexpectedType' });
    });
    // own, finite-number metrics only, checked directly (the branch scan only sees enumerable properties)
    for (const k of ['totalCapital', 'totalDebtService', 'weightedAverageCost', 'wacc']) {
      if (!has(st, k)) p.push({ path: 'raw.stack.' + k, code: 'missing' });
      else if (typeof st[k] !== 'number') p.push({ path: 'raw.stack.' + k, code: 'unexpectedType' });
      else if (!Number.isFinite(st[k])) p.push({ path: 'raw.stack.' + k, code: 'notFinite' });
    }
  }
  return p;
}

/**
 * Inspects the engine output. Returns { essentialProblems, sections, sectionProblems }.
 * ok needs: all eleven scalars finite numbers, expected key set, required stack/facility structure, no problem in the stack/facility
 * branches, and every optional section ok or notApplicable. Anything not inspected (limit, cycle, unexpected type) is never ok.
 */
function inspectOutput(raw, v) {
  const essential = [];
  if (!isPlain(raw)) return { essential: [{ path: 'raw', code: 'unexpectedType' }], sections: null, sectionProblems: [] };
  const keys = Object.keys(raw);
  for (const k of RAW_KEYS) if (!keys.includes(k)) essential.push({ path: 'raw.' + k, code: 'missing' });
  for (const k of keys) if (!RAW_KEYS.includes(k)) essential.push({ path: 'raw.' + k, code: 'unexpectedField' });
  for (const k of ESSENTIAL_SCALARS) if (keys.includes(k)) { if (typeof raw[k] !== 'number') essential.push({ path: 'raw.' + k, code: 'unexpectedType' }); else if (!Number.isFinite(raw[k])) essential.push({ path: 'raw.' + k, code: 'notFinite' }); }
  const seen = new Set(), add = p => { const id = p.path + '|' + p.code; if (!seen.has(id)) { seen.add(id); essential.push(p); } };
  essential.splice(0).forEach(add);
  for (const p of structureProblems(raw, v)) add(p);
  for (const k of ['stack', 'facilities']) if (keys.includes(k)) for (const p of inspectBranch(raw[k], 'raw.' + k).problems) add(p);
  const sections = {}, sectionProblems = [];
  for (const [name, key] of Object.entries(SECTION_KEYS)) {
    if (!keys.includes(key)) { sections[name] = 'unexpectedType'; continue; }
    const x = raw[key];
    if (name === 'acquisitionStructureResult' && v.provinceState !== 'BC') { sections[name] = x === null ? 'notApplicable' : 'unexpectedType'; if (x !== null) sectionProblems.push({ path: 'raw.' + key, code: 'unexpectedType' }); continue; }
    if (x === null) { sections[name] = 'unavailable'; sectionProblems.push({ path: 'raw.' + key, code: 'engineReturnedNull' }); continue; }
    if (!isPlain(x)) { sections[name] = 'unexpectedType'; sectionProblems.push({ path: 'raw.' + key, code: 'unexpectedType' }); continue; }
    const r = inspectBranch(x, 'raw.' + key);
    if (!r.problems.length) { sections[name] = 'ok'; continue; }
    sections[name] = r.exhausted ? 'uninspected' : r.problems.every(q => q.code === 'notFinite') ? 'nonFinite' : 'unexpectedType';
    for (const q of r.problems) sectionProblems.push(q);
  }
  return { essential, sections, sectionProblems };
}

function fullCalculate(request, deps) {
  const req = isPlain(request) ? request : null;
  const val = validate(req);
  const { revision, fields, identity } = val;
  if (val.issues.length) {
    const res = baseResult(revision, identity, val.issues.some(i => i.category !== 'incomplete') ? 'invalid' : 'incomplete', val.issues, val.notes);
    res.derived = val.derived;   // present only for a timeline-limit failure, so the offending total can be shown
    return res;
  }
  const res = baseResult(revision, identity, 'ok', [], val.notes);
  const v = normalizedFrom(fields);
  res.normalizedInputs = v; res.derived = val.derived;

  // dependencies (only after a valid request)
  let CALC = null, depsOk = isPlain(deps);
  if (depsOk) {
    try {
      CALC = deps.CALC;
      depsOk = CALC !== null && (typeof CALC === 'object' || typeof CALC === 'function') && REQUIRED_CALC.every(n => typeof CALC[n] === 'function');
    } catch (e) { depsOk = false; }
  }
  if (!depsOk) { res.status = 'error'; res.calculationError = { name: 'EngineUnavailable', message: 'deps.CALC must provide: ' + REQUIRED_CALC.join(', ') }; return res; }
  let snap;
  try { snap = snapshotEngineIdentity(deps.engineIdentity); } catch (e) { snap = { ok: false }; }
  if (!snap.ok) { res.status = 'error'; res.calculationError = { name: 'EngineIdentityInvalid', message: 'deps.engineIdentity must be a flat plain object of at most ' + IDENTITY_LIMITS.maxKeys + ' string, finite-number, boolean or null values' }; return res; }
  res.engine = { declared: snap.declared, declaredCanonical: snap.canonical, verified: false };

  let raw;
  try { raw = devstudioCompute(Object.assign({}, v), { CALC }); }
  catch (e) { res.status = 'error'; res.calculationError = { name: String(e && e.name), message: String(e && e.message) }; return res; }

  const insp = inspectOutput(raw, v);
  res.sections = insp.sections;
  const outIssues = insp.essential.concat(insp.sectionProblems).map(p => issue(p.path, p.code, 'output'));
  if (insp.essential.length) {
    res.status = 'unavailable'; res.issues = outIssues; res.unavailableFields = Array.from(new Set(insp.essential.map(p => p.path)));
    return res;
  }
  res.raw = raw;
  const bad = Object.values(insp.sections).some(s => s !== 'ok' && s !== 'notApplicable');
  if (bad) { res.status = 'partial'; res.issues = outIssues; res.unavailableFields = Array.from(new Set(insp.sectionProblems.map(p => p.path))); }
  return res;
}

/**
 * Pure FRESHNESS test (never display permission): kind, package version, contract, mode, strict revision, input identity and, when the
 * caller passes deps.engineIdentity, the canonical declared engine identity must all equal those of the CURRENT request/deps. The status is
 * deliberately not consulted: non-ok results stay matchable so their messages can be shown. Check result.status separately before using raw.
 */
function fullResultMatchesRequest(result, request, deps) {
  if (!isPlain(result) || !isPlain(request)) return false;
  const rev = revisionOf(request.inputRevision);
  if (!rev.ok) return false;
  if (!(result.kind === 'result' && result.calculationPackageVersion === PACKAGE_VERSION && result.contractVersion === FULL_ADAPTER_CONTRACT_VERSION && result.mode === 'full'
    && request.mode === 'full' && request.contractVersion === FULL_ADAPTER_CONTRACT_VERSION && result.inputRevision === rev.value
    && typeof result.inputIdentity === 'string' && result.inputIdentity === fullInputIdentity(request.inputs))) return false;
  if (deps !== undefined && isPlain(deps) && deps.engineIdentity !== undefined) {
    let snap; try { snap = snapshotEngineIdentity(deps.engineIdentity); } catch (e) { return false; }
    if (!snap.ok || !isPlain(result.engine) || result.engine.declaredCanonical !== snap.canonical) return false;
  }
  return true;
}

module.exports = {
  FULL_ADAPTER_CONTRACT_VERSION, FULL_FIELDS, FULL_OPERATIONAL_LIMITS, FULL_DISCLOSURES: DISCLOSURES, FULL_ACTIVATION_PREDICATES: ACTIVATION_PREDICATES,
  FULL_REQUIRED_ENGINE_CAPABILITIES: REQUIRED_CALC, FULL_INSPECTION_LIMITS: INSPECT_LIMITS, FULL_ENGINE_IDENTITY_LIMITS: IDENTITY_LIMITS, FULL_ENUMS: ENUMS,
  fullCalculate, fullInputIdentity, fullResultMatchesRequest
};
