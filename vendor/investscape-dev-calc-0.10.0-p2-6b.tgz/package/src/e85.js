'use strict';
/**
 * E85 preview payload validator, P2-2G.
 *
 * Mechanically relocated from investscape-v2-remastered.html (reference SHA-256 84cf6e13...c193c83): e85InternalKeyIn(),
 * e85PayloadIssues() and the four contract constants they read (E85_RESPONSE_KEYS, E85_ARRAY_KEYS, E85_STATUSES, E85_INTERNAL_KEYS).
 *
 * This is a CONTRACT-SHAPE guard for the synthetic e85-public-2 preview samples. It returns the list of issue strings (an empty list
 * means the sample passed the guard). It does NOT establish legal correctness, pack readiness or permission to release; a payload that
 * passes is still labelled synthetic, NOT_RELEASED and AS_OF resolution DISABLED by its own content, and no lookup is made.
 *
 * Boundary edits relative to the page text (all of them):
 *   1. e85PayloadIssues gains an optional explicit second argument  deps = {}  and binds  const t = deps.t || e85EnglishT;
 *      the page-global t() (translation) becomes that injected message function. Its signature is the page's: t(key, fallback, vars).
 *   2. e85EnglishT is the page's t() with an EMPTY dictionary (fallback text, then "{name}" interpolation by split/join): the raw
 *      English issue text. Translation, rendering (e85UnavailableHtml), sample selection and UI state stay outside this module.
 *   3. the four contract constants are frozen and exported as E85_CONTRACT (the page leaves them mutable).
 * Statement order and logic are otherwise identical. No state, DOM, engine, clock or storage; input is never mutated.
 *
 * Legacy behaviours preserved on purpose: the guard returns early after a missing response, after an unsupported contract version and
 * after missing top-level keys; internal-key search stops at depth 12 and reports the first key found in depth-first property order;
 * String() is applied to the offending value in messages (so a null-prototype value in status or version throws TypeError).
 */
const E85_RESPONSE_KEYS = Object.freeze(['contractVersion','status','statusMeaning','temporal','jurisdictionId','designation','fields','practicalCapacity','callerAssertions','warnings','gaps','blockers','temporalFindings','sourceFindings','engine','packReadiness']);
const E85_ARRAY_KEYS = Object.freeze(['fields','warnings','gaps','blockers','temporalFindings','sourceFindings']);
const E85_STATUSES = Object.freeze(['MACHINE_RESOLVED','MACHINE_RESOLVED_WITH_WARNINGS','MANUAL_REVIEW_REQUIRED','DATA_GAP']);
// Never public: the internal temporal diagnostic, the decision trace and the server-side readiness gate.
const E85_INTERNAL_KEYS = Object.freeze(['temporalLineageDiagnostic','trace','publicReady','knownStarts']);
const E85_CONTRACT = Object.freeze({ contractVersion: 'e85-public-2', responseKeys: E85_RESPONSE_KEYS, arrayKeys: E85_ARRAY_KEYS, statuses: E85_STATUSES, internalKeys: E85_INTERNAL_KEYS });

function e85EnglishT(key, fallback, vars){
  let str = fallback || key;
  if(vars){ Object.keys(vars).forEach(k=>{ str = str.split('{'+k+'}').join(vars[k]); }); }
  return str;
}

function e85InternalKeyIn(v, depth){
  if(v===null || typeof v!=='object' || depth>12) return null;
  for(const k of Object.keys(v)){
    if(E85_INTERNAL_KEYS.includes(k)) return k;
    const inner = e85InternalKeyIn(v[k], depth+1);
    if(inner) return inner;
  }
  return null;
}
function e85PayloadIssues(entry, deps = {}){
  const t = deps.t || e85EnglishT;
  const out = [];
  const missing = key => out.push(t('e85.err.missingKey','Malformed sample: {key} is missing or has the wrong type.',{key}));
  const isObj = v => v!==null && typeof v==='object' && !Array.isArray(v);
  const isStr = v => typeof v==='string';
  if(!isObj(entry) || !isObj(entry.response)){ missing('response'); return out; }
  const r = entry.response;
  if(r.contractVersion!=='e85-public-2'){
    out.push(t('e85.err.unsupportedVersion','Unsupported contract version {v}. Only e85-public-2 is displayed.',{v:String(r.contractVersion)}));
    return out;
  }
  const s = entry.sample;
  if(!isObj(s) || s.kind!=='ENGINE_GENERATED_SYNTHETIC_FIXTURE' || s.notLiveData!==true || s.notACivicParcel!==true) out.push(t('e85.err.notSynthetic','Malformed sample: it is not labelled as a synthetic, disconnected example.'));
  for(const k of E85_RESPONSE_KEYS) if(r[k]===undefined || r[k]===null) missing(k);
  if(out.length) return out;
  for(const k of E85_ARRAY_KEYS) if(!Array.isArray(r[k])) missing(k);
  if(!E85_STATUSES.includes(r.status)) out.push(t('e85.err.status','Malformed sample: status {v} is not an e85-public-2 status.',{v:String(r.status)}));
  if(!isStr(r.statusMeaning)) missing('statusMeaning');
  if(!isStr(r.jurisdictionId)) missing('jurisdictionId');
  if(!isObj(r.temporal) || r.temporal.mode!=='AS_OF' || !/^\d{4}-\d{2}-\d{2}$/.test(String(r.temporal.asOfDate))) missing('temporal');
  const d = r.designation;
  if(!isObj(d) || !isStr(d.value) || !isStr(d.datasetId) || !isStr(d.datasetVersionId) || !isStr(d.snapshotSha256) || !Array.isArray(d.featureIds)) missing('designation');
  const e = r.engine;
  if(!isObj(e) || !Array.isArray(e.rulePackIds) || !Array.isArray(e.unresolvedPackIds) || !isStr(e.policyVersionId)) missing('engine');
  if(!isObj(r.callerAssertions)) missing('callerAssertions');
  if(!isObj(r.practicalCapacity)) missing('practicalCapacity');
  const p = r.packReadiness;
  if(!isObj(p) || !isStr(p.state)) missing('packReadiness');
  else if(p.state==='NOT_SUPPLIED'){ if(!isStr(p.meaning)) missing('packReadiness.meaning'); }
  else if(p.state==='DISCLOSED'){
    for(const k of ['basis','legalPackId','releaseStatus','asOfResolution','definitionHistory','versionValidity','meaning']) if(!isStr(p[k])) missing('packReadiness.'+k);
    if(!isObj(p.licence) || !isStr(p.licence.status) || !Array.isArray(p.licence.sources)) missing('packReadiness.licence');
    if(!isObj(p.amendmentIndex) || !isStr(p.amendmentIndex.captureDate) || !isStr(p.amendmentIndex.indexSha256) || !isStr(p.amendmentIndex.currency)) missing('packReadiness.amendmentIndex');
    if(!Array.isArray(p.withheldValues)) missing('packReadiness.withheldValues');
    if(!Array.isArray(p.openGates)) missing('packReadiness.openGates');
  } else out.push(t('e85.err.readinessState','Malformed sample: packReadiness.state {v} is neither DISCLOSED nor NOT_SUPPLIED. An unrecognised readiness is never treated as ready.',{v:String(p.state)}));
  const q = entry.request;
  const pt = isObj(q) && isObj(q.parcel) ? q.parcel.point : undefined;
  if(!isObj(q) || !isObj(q.parcel) || Object.keys(q.parcel).join()!=='point' || !isObj(pt) || !Number.isFinite(pt.x) || !Number.isFinite(pt.y) || !isStr(pt.crs)) out.push(t('e85.err.pointOnly','Malformed sample: the request must locate the parcel by a point only.'));
  else if(!isObj(q.temporal) || q.temporal.mode!=='AS_OF' || q.temporal.asOfDate!==(r.temporal && r.temporal.asOfDate)) missing('request.temporal');
  const internal = e85InternalKeyIn(entry, 0);
  if(internal) out.push(t('e85.err.internalKey','Malformed sample: the internal field {key} must never appear in a public payload.',{key:internal}));
  return out;
}
module.exports = { E85_CONTRACT, e85EnglishT, e85InternalKeyIn, e85PayloadIssues };
