'use strict';
/**
 * Quick development screen arithmetic (P2-2A).
 *
 * Mechanically relocated from paintDevelopmentQuickScreen() in
 * investscape-v2-remastered.html (reference SHA-256 84cf6e13...c193c83). Nothing is
 * re-derived: the expressions, their order and their operand reads are the same.
 *
 * RAW LEGACY BEHAVIOUR, preserved on purpose (strict parity gate):
 *   - no validation, no coercion, no status: a non-numeric operand yields NaN,
 *     Infinity, string concatenation or a thrown TypeError exactly as the page does;
 *   - a falsy holdPeriodYears (0, '', undefined, NaN, null) is treated as 1 year,
 *     then floored at 0.5 year;
 *   - returnOnCost is null only when totalCost is falsy (0, NaN, '', null, undefined);
 *   - simpleIrr is null only when totalCost is not > 0.
 * Validated, status-bearing native-page results belong to a separate adapter slice.
 *
 * No state, DOM, formatting, translation, clock or storage. No engine is used.
 * Basis: Quick only. It is NOT the Full (devstudioCompute) basis and must not be unified with it.
 */
function calcQuick(deal, extra) {
  const d = deal, x = extra;
  const landCost = d.purchasePrice;
  const softCosts = x.constructionCostTotal * (x.softCostPct / 100);
  const totalCost = landCost + x.constructionCostTotal + softCosts;
  const requiredProfit = x.grossSelloutValue * (x.requiredProfitMarginPct / 100);
  const residualLandValue = x.grossSelloutValue - x.constructionCostTotal - softCosts - requiredProfit;
  const actualProfit = x.grossSelloutValue - totalCost;
  const marginPct = totalCost ? actualProfit / totalCost : null;
  const years = Math.max(d.holdPeriodYears || 1, 0.5);
  const simpleIRR = totalCost > 0 ? Math.pow(1 + actualProfit / totalCost, 1 / years) - 1 : null;
  return {
    totalCost,
    grossSelloutValue: x.grossSelloutValue,
    residualLandValue,
    landCost,
    // The page's "room to pay more" / "paying above residual" wording keys off this comparison (false for NaN).
    residualCoversLand: residualLandValue >= landCost,
    returnOnCost: marginPct,
    simpleIrr: simpleIRR
  };
}
module.exports = { calcQuick };
