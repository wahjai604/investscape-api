'use strict';
const { calcQuick } = require('./quick');
const { buildFinancingFacilities, devstudioCompute } = require('./full');
const { solveRLVWithFinancing } = require('./rlv');
const { smoothstep, smoothstepAverageDrawFactor, calculateXIRR, computeStagedRollup } = require('./staged');
const { HANDOFF_CONFIG, quickToFullHandoffPlan } = require('./handoff');
const { PACKAGE_VERSION } = require('./version');
const { QUICK_ADAPTER_CONTRACT_VERSION, QUICK_FIELDS, QUICK_DISCLOSURES, quickCalculate, quickInputIdentity, quickResultMatchesRequest } = require('./quick-adapter');
const { FULL_ADAPTER_CONTRACT_VERSION, FULL_FIELDS, FULL_OPERATIONAL_LIMITS, FULL_DISCLOSURES, FULL_ACTIVATION_PREDICATES, FULL_REQUIRED_ENGINE_CAPABILITIES, FULL_INSPECTION_LIMITS, FULL_ENGINE_IDENTITY_LIMITS, FULL_ENUMS, fullCalculate, fullInputIdentity, fullResultMatchesRequest } = require('./full-adapter');
const { E85_CONTRACT, e85EnglishT, e85InternalKeyIn, e85PayloadIssues } = require('./e85');
const { DEV_TAX_JURISDICTIONS, devstudioTaxApplicability } = require('./tax');
/**
 * Identification only. Engine release versions are UNKNOWN. The package contains no engine bundle: the caller injects
 * CALC (the calc engine) through deps. Quick uses no engine.
 */
const MODULE_INFO = Object.freeze({
  moduleVersion: PACKAGE_VERSION, slices: Object.freeze(['quick', 'full-single-phase', 'rlv-single-phase', 'staged-rollup-xirr', 'tax-applicability', 'handoff-mapping', 'e85-payload-validator', 'quick-adapter', 'full-adapter']),
  engines: Object.freeze({ quick: 'none', full: 'calc (injected, not bundled)', rlv: 'calc (injected, via the Full calculation)', staged: 'calc (injected, via the Full calculation)', tax: 'tax (injected, not bundled)', handoff: 'none (pure mapping; frozen reference lists bundled, config injectable)', e85: 'none (pure contract-shape validation; t() injectable, English fallback by default)', quickAdapter: 'none (pure adapter around calcQuick)', fullAdapter: 'calc (injected, not bundled; engine identity caller-declared, unverified; release versions UNKNOWN)' }),
  referenceHtmlSha256: '84cf6e13043fe392e8c4a9f82e37ba90ec68b86f948c8f91082bcc9810193c83'
});
module.exports = { calcQuick, buildFinancingFacilities, devstudioCompute, solveRLVWithFinancing, smoothstep, smoothstepAverageDrawFactor, calculateXIRR, computeStagedRollup, DEV_TAX_JURISDICTIONS, devstudioTaxApplicability, HANDOFF_CONFIG, quickToFullHandoffPlan, E85_CONTRACT, e85EnglishT, e85InternalKeyIn, e85PayloadIssues, QUICK_ADAPTER_CONTRACT_VERSION, QUICK_FIELDS, QUICK_DISCLOSURES, quickCalculate, quickInputIdentity, quickResultMatchesRequest, FULL_ADAPTER_CONTRACT_VERSION, FULL_FIELDS, FULL_OPERATIONAL_LIMITS, FULL_DISCLOSURES, FULL_ACTIVATION_PREDICATES, FULL_REQUIRED_ENGINE_CAPABILITIES, FULL_INSPECTION_LIMITS, FULL_ENGINE_IDENTITY_LIMITS, FULL_ENUMS, fullCalculate, fullInputIdentity, fullResultMatchesRequest, MODULE_INFO };
